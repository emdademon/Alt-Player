package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppUpdateManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Alt Player", appName)
    assertEquals("Offline Media • Auto-Update", context.getString(R.string.offline_privacy_badge))
  }

  @Test
  fun `github latest release json parser extracts apk download url and release notes`() {
    val json = """
      {
        "tag_name": "v1.1",
        "name": "Alt Player v1.1",
        "draft": false,
        "body": "- Added OTA updater\n- Performance polish",
        "assets": [
          {
            "name": "checksums.txt",
            "size": 128,
            "browser_download_url": "https://github.com/emdademon/Alt-Player/releases/download/v1.1/checksums.txt"
          },
          {
            "name": "AltPlayer-v1.1.apk",
            "size": 18432000,
            "browser_download_url": "https://github.com/emdademon/Alt-Player/releases/download/v1.1/AltPlayer-v1.1.apk"
          }
        ]
      }
    """.trimIndent()

    val parsed = AppUpdateManager.parseLatestReleaseJson(json)
    assertNotNull(parsed)
    assertEquals("1.1", parsed!!.versionTag)
    assertEquals("v1.1", parsed.rawTagName)
    assertEquals("Alt Player v1.1", parsed.releaseName)
    assertEquals("AltPlayer-v1.1.apk", parsed.apkFileName)
    assertEquals(18432000L, parsed.apkSizeBytes)
    assertEquals(
      "https://github.com/emdademon/Alt-Player/releases/download/v1.1/AltPlayer-v1.1.apk",
      parsed.apkDownloadUrl
    )

    val emptyAssetsJson = """{"tag_name": "v1.2", "draft": false, "assets": []}"""
    assertNull(AppUpdateManager.parseLatestReleaseJson(emptyAssetsJson))

    val draftJson = """
      {
        "tag_name": "v1.3",
        "draft": true,
        "assets": [{"name": "app.apk", "browser_download_url": "https://example.com/app.apk"}]
      }
    """.trimIndent()
    assertNull(AppUpdateManager.parseLatestReleaseJson(draftJson))
  }
}
