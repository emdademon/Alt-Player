package com.example

import com.example.data.MediaStoreVideoRepository
import com.example.data.PlaybackPreferencesRepository
import com.example.data.computeResolutionBadge
import com.example.data.formatDuration
import com.example.data.formatFileSize
import com.example.player.AspectMode
import com.example.player.LoopMode
import com.example.player.PlayerMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AltPlayerUnitTest {

    @Test
    fun `resolution badges and formatters work accurately`() {
        assertEquals("4K", computeResolutionBadge(3840, 2160))
        assertEquals("1080p", computeResolutionBadge(1920, 1080))
        assertEquals("720p", computeResolutionBadge(1280, 720))
        assertEquals("02:05", formatDuration(125_000L))
        assertEquals("1:01:05", formatDuration(3_665_000L))
        assertEquals("1.50 GB", formatFileSize((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun `supported video formats include mp4 mkv avi and webm`() {
        assertTrue(MediaStoreVideoRepository.isSupportedVideoFormat("mp4", "video/mp4"))
        assertTrue(MediaStoreVideoRepository.isSupportedVideoFormat("mkv", "video/x-matroska"))
        assertTrue(MediaStoreVideoRepository.isSupportedVideoFormat("avi", "video/x-msvideo"))
        assertTrue(MediaStoreVideoRepository.isSupportedVideoFormat("webm", "video/webm"))
        assertFalse(MediaStoreVideoRepository.isSupportedVideoFormat("jpg", "image/jpeg"))
    }

    @Test
    fun `private vault PIN hashing verifies matching pins and rejects mismatches`() {
        val stored = PlaybackPreferencesRepository.hashPin("2580")
        assertTrue(PlaybackPreferencesRepository.verifyPin("2580", stored))
        assertFalse(PlaybackPreferencesRepository.verifyPin("1234", stored))
        assertFalse(PlaybackPreferencesRepository.verifyPin("2580", null))
    }

    @Test
    fun `player math utilities clamp zoom subtitle sync loudness boost and pip aspect`() {
        assertEquals(0.25f, PlayerMath.clampZoomScale(0.10f), 0.001f)
        assertEquals(1.35f, PlayerMath.clampZoomScale(1.35f), 0.001f)
        assertEquals(2.00f, PlayerMath.clampZoomScale(3.50f), 0.001f)

        assertEquals(-30_000L, PlayerMath.clampSubtitleOffsetMs(-99_000L))
        assertEquals(30_000L, PlayerMath.clampSubtitleOffsetMs(99_000L))
        assertEquals("+0.3s", PlayerMath.formatSubtitleOffset(300L))
        assertEquals("-0.5s", PlayerMath.formatSubtitleOffset(-500L))
        assertEquals("0.0s", PlayerMath.formatSubtitleOffset(0L))

        assertEquals(0, PlayerMath.computeLoudnessGainMb(100))
        assertEquals(1500, PlayerMath.computeLoudnessGainMb(200))

        assertEquals(16 to 9, PlayerMath.clampPipAspectRatio(0, 0))
        val (wideNum, wideDen) = PlayerMath.clampPipAspectRatio(5000, 1000)
        assertTrue(wideNum.toFloat() / wideDen.toFloat() <= 2.21f)
        val (tallNum, tallDen) = PlayerMath.clampPipAspectRatio(100, 1000)
        assertTrue(tallNum.toFloat() / tallDen.toFloat() >= 0.44f)

        assertEquals(LoopMode.REPEAT_ONE, LoopMode.OFF.next())
        assertEquals(LoopMode.REPEAT_FOLDER, LoopMode.REPEAT_ONE.next())
        assertEquals(LoopMode.OFF, LoopMode.REPEAT_FOLDER.next())
        assertEquals(AspectMode.STRETCH, AspectMode.FIT.next())
    }
}
