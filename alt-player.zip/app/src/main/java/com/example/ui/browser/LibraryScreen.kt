package com.example.ui.browser

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LibraryTab
import com.example.data.MediaAccessState
import com.example.data.PlaybackPreferencesRepository
import com.example.data.SortOption
import com.example.data.SortOrder
import com.example.data.VideoFolder
import com.example.data.VideoItem
import com.example.ui.components.AltPlayerLogo
import com.example.ui.components.ContinueWatchingBanner
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.FolderCard
import com.example.ui.components.MediaInfoDialog
import com.example.ui.components.PrivacyShieldSheet
import com.example.ui.components.RenameVideoDialog
import com.example.ui.components.SortOptionsSheet
import com.example.ui.components.VideoCard
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldOffline
import com.example.ui.theme.OnCyanContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    uiState: LibraryUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectTab: (LibraryTab) -> Unit,
    onSelectSort: (SortOption, SortOrder) -> Unit,
    onToggleGridView: () -> Unit,
    onRefreshScan: (Boolean) -> Unit,
    onOpenFolder: (VideoFolder) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivateVault: () -> Unit,
    onPlayVideo: (VideoItem, List<VideoItem>) -> Unit,
    onOpenExternalUri: (Uri) -> Unit,
    onSetFolderHidden: (String, Boolean) -> Unit,
    onInspectMediaInfo: (VideoItem) -> Unit,
    onDismissMediaInfo: () -> Unit,
    createDeleteIntentSender: (List<Uri>) -> IntentSender?,
    createWriteIntentSender: (List<Uri>) -> IntentSender?,
    onDeleteVideosLegacy: (List<VideoItem>, (IntentSender) -> Unit) -> Unit,
    onPerformRename: (VideoItem, String, (IntentSender) -> Unit) -> Unit,
    onMoveVideoToVault: (VideoItem, (VideoItem) -> Unit) -> Unit,
    getShareableUri: (VideoItem) -> Uri,
    onClearStatusMessage: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showSortSheet by remember { mutableStateOf(false) }
    var showPrivacySheet by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<VideoItem?>(null) }
    var pendingRenameNewTitle by remember { mutableStateOf<String?>(null) }
    var legacyDeleteVideos by remember { mutableStateOf<List<VideoItem>?>(null) }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        onClearStatusMessage()
    }

    val permissionsToRequest = remember {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO
            )
            else -> arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefreshScan(false)
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onOpenExternalUri(uri)
    }

    val deleteSenderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            onRefreshScan(false)
        }
    }

    val writeSenderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val target = renameTarget
        val newName = pendingRenameNewTitle
        if (result.resultCode == Activity.RESULT_OK && target != null && !newName.isNullOrBlank()) {
            onPerformRename(target, newName) { /* already granted */ }
        }
        renameTarget = null
        pendingRenameNewTitle = null
    }

    fun requestDeleteVideos(videos: List<VideoItem>) {
        val sender = createDeleteIntentSender(videos.map { it.uri })
        if (sender != null) {
            deleteSenderLauncher.launch(IntentSenderRequest.Builder(sender).build())
        } else {
            legacyDeleteVideos = videos
        }
    }

    fun requestRenameVideo(video: VideoItem, newTitle: String) {
        val sender = createWriteIntentSender(listOf(video.uri))
        if (sender != null) {
            renameTarget = video
            pendingRenameNewTitle = newTitle
            writeSenderLauncher.launch(IntentSenderRequest.Builder(sender).build())
        } else {
            onPerformRename(video, newTitle) { recoverable ->
                renameTarget = video
                pendingRenameNewTitle = newTitle
                writeSenderLauncher.launch(IntentSenderRequest.Builder(recoverable).build())
            }
            renameTarget = null
        }
    }

    fun shareVideo(video: VideoItem) {
        val shareUri = getShareableUri(video)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share video"))
    }

    val resumeFabTarget = uiState.continueWatchingVideo ?: uiState.filteredVideos.firstOrNull()

    Scaffold(
        containerColor = AmoledBlack,
        contentWindowInsets = WindowInsets.statusBars,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            if (resumeFabTarget != null) {
                FloatingActionButton(
                    onClick = {
                        val playlist = uiState.folders
                            .find { it.bucketId == resumeFabTarget.bucketId }
                            ?.videos ?: uiState.filteredVideos
                        onPlayVideo(resumeFabTarget, playlist)
                    },
                    shape = CircleShape,
                    containerColor = ElectricCyan,
                    contentColor = AmoledBlack,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("home_resume_fab")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = stringResource(R.string.menu_play_resume),
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0A1220), AmoledBlack, AmoledBlack)
                    )
                )
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                LibraryHeader(
                    isGridView = uiState.isGridView,
                    onPrivacyClick = { showPrivacySheet = true },
                    onPrivateVaultClick = onOpenPrivateVault,
                    onToggleGridView = onToggleGridView,
                    onOpenFileClick = { openDocumentLauncher.launch(arrayOf("video/*")) },
                    onSortClick = { showSortSheet = true },
                    onSettingsClick = onOpenSettings
                )

                SearchCapsule(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )

                if (uiState.accessState == MediaAccessState.GRANTED_ALL ||
                    uiState.accessState == MediaAccessState.GRANTED_PARTIAL
                ) {
                    LibraryTabRow(
                        activeTab = uiState.activeTab,
                        folderCount = uiState.filteredFolders.size,
                        videoCount = uiState.filteredVideos.size,
                        onSelectTab = onSelectTab,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                AnimatedVisibility(visible = uiState.accessState == MediaAccessState.GRANTED_PARTIAL) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        color = CyanContainer.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.partial_access_banner),
                                style = MaterialTheme.typography.bodySmall,
                                color = OnCyanContainer,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = stringResource(R.string.grant_full_access),
                                style = MaterialTheme.typography.labelLarge,
                                color = ElectricCyan,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { permissionLauncher.launch(permissionsToRequest) }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("grant_full_access_button")
                            )
                        }
                    }
                }

                when {
                    uiState.isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ElectricCyan)
                        }
                    }

                    uiState.accessState == MediaAccessState.DENIED ||
                        uiState.accessState == MediaAccessState.UNKNOWN -> {
                        PermissionRequestView(
                            onGrantPermission = { permissionLauncher.launch(permissionsToRequest) },
                            onPickFile = { openDocumentLauncher.launch(arrayOf("video/*")) }
                        )
                    }

                    uiState.allVideos.isEmpty() -> {
                        PullToRefreshBox(
                            isRefreshing = uiState.isRefreshing,
                            onRefresh = { onRefreshScan(true) },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            EmptyLibraryView(
                                isSearchEmpty = false,
                                onAction = { openDocumentLauncher.launch(arrayOf("video/*")) },
                                onRescan = { onRefreshScan(true) }
                            )
                        }
                    }

                    (uiState.activeTab == LibraryTab.FOLDERS && uiState.filteredFolders.isEmpty()) ||
                        (uiState.activeTab == LibraryTab.ALL_VIDEOS && uiState.filteredVideos.isEmpty()) -> {
                        PullToRefreshBox(
                            isRefreshing = uiState.isRefreshing,
                            onRefresh = { onRefreshScan(true) },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            EmptyLibraryView(
                                isSearchEmpty = true,
                                onAction = { onSearchQueryChange("") },
                                onRescan = { onRefreshScan(true) }
                            )
                        }
                    }

                    else -> {
                        PullToRefreshBox(
                            isRefreshing = uiState.isRefreshing,
                            onRefresh = { onRefreshScan(true) },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                                val columns = when {
                                    uiState.isGridView && maxWidth >= 640.dp -> 3
                                    uiState.isGridView -> 2
                                    maxWidth >= 640.dp -> 2
                                    else -> 1
                                }
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(columns),
                                    contentPadding = PaddingValues(
                                        start = 16.dp,
                                        end = 16.dp,
                                        top = 6.dp,
                                        bottom = 96.dp
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    val continueVideo = uiState.continueWatchingVideo
                                    if (continueVideo != null && uiState.searchQuery.isBlank()) {
                                        item(span = { GridItemSpan(columns) }) {
                                            ContinueWatchingBanner(
                                                video = continueVideo,
                                                positionMs = uiState.continueWatchingPositionMs,
                                                onResumeClick = {
                                                    val folderVideos = uiState.folders
                                                        .find { it.bucketId == continueVideo.bucketId }
                                                        ?.videos ?: uiState.filteredVideos
                                                    onPlayVideo(continueVideo, folderVideos)
                                                },
                                                modifier = Modifier.padding(bottom = 4.dp)
                                            )
                                        }
                                    }

                                    if (uiState.activeTab == LibraryTab.FOLDERS) {
                                        items(
                                            items = uiState.filteredFolders,
                                            key = { it.bucketId }
                                        ) { folder ->
                                            val hasUnwatched = folder.videos.any { vid ->
                                                val key = PlaybackPreferencesRepository.uriKey(vid.uri.toString())
                                                key !in uiState.watchedUris
                                            }
                                            FolderCard(
                                                folder = folder,
                                                hasUnwatchedVideos = hasUnwatched,
                                                isGrid = uiState.isGridView,
                                                onClick = { onOpenFolder(folder) },
                                                onPlayFirst = {
                                                    folder.videos.firstOrNull()?.let { first ->
                                                        onPlayVideo(first, folder.videos)
                                                    }
                                                },
                                                onToggleHide = {
                                                    onSetFolderHidden(folder.bucketId, !folder.isHidden)
                                                },
                                                onDeleteFolder = {
                                                    requestDeleteVideos(folder.videos)
                                                }
                                            )
                                        }
                                    } else {
                                        items(
                                            items = uiState.filteredVideos,
                                            key = { it.id }
                                        ) { video ->
                                            val key = PlaybackPreferencesRepository.uriKey(video.uri.toString())
                                            val resumeMs = uiState.positionsByUri[key] ?: 0L
                                            val isWatched = key in uiState.watchedUris
                                            VideoCard(
                                                video = video,
                                                resumePositionMs = resumeMs,
                                                isWatched = isWatched,
                                                isGrid = uiState.isGridView,
                                                onClick = { onPlayVideo(video, uiState.filteredVideos) },
                                                onRename = { renameTarget = video },
                                                onDelete = { requestDeleteVideos(listOf(video)) },
                                                onShare = { shareVideo(video) },
                                                onMoveToVault = {
                                                    onMoveVideoToVault(video) { original ->
                                                        requestDeleteVideos(listOf(original))
                                                    }
                                                },
                                                onProperties = { onInspectMediaInfo(video) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortSheet) {
        SortOptionsSheet(
            currentOption = uiState.sortOption,
            currentOrder = uiState.sortOrder,
            onSelectSort = onSelectSort,
            onDismiss = { showSortSheet = false }
        )
    }

    if (showPrivacySheet) {
        PrivacyShieldSheet(onDismiss = { showPrivacySheet = false })
    }

    renameTarget?.takeIf { pendingRenameNewTitle == null }?.let { target ->
        RenameVideoDialog(
            initialTitle = target.title,
            onConfirm = { newTitle ->
                requestRenameVideo(target, newTitle)
            },
            onDismiss = { renameTarget = null }
        )
    }

    legacyDeleteVideos?.let { targets ->
        DeleteConfirmDialog(
            title = if (targets.size == 1) "Delete Video?" else "Delete ${targets.size} Videos?",
            message = "This will permanently remove the selected video file(s) from your device.",
            onConfirm = {
                onDeleteVideosLegacy(targets) { recoverable ->
                    deleteSenderLauncher.launch(IntentSenderRequest.Builder(recoverable).build())
                }
                legacyDeleteVideos = null
            },
            onDismiss = { legacyDeleteVideos = null }
        )
    }

    MediaInfoDialog(
        isLoading = uiState.isLoadingMediaInfo,
        info = uiState.inspectedMediaInfo,
        onDismiss = onDismissMediaInfo
    )
}

@Composable
private fun LibraryHeader(
    isGridView: Boolean,
    onPrivacyClick: () -> Unit,
    onPrivateVaultClick: () -> Unit,
    onToggleGridView: () -> Unit,
    onOpenFileClick: () -> Unit,
    onSortClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AltPlayerLogo(modifier = Modifier.size(38.dp))

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                maxLines = 1
            )
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(onClick = onPrivacyClick)
                    .testTag("offline_privacy_badge"),
                color = EmeraldOffline.copy(alpha = 0.14f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = EmeraldOffline,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = stringResource(R.string.offline_privacy_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldOffline,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        IconButton(
            onClick = onPrivateVaultClick,
            modifier = Modifier.testTag("private_vault_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = stringResource(R.string.private_vault_title),
                tint = TextPrimary
            )
        }

        IconButton(
            onClick = onToggleGridView,
            modifier = Modifier.testTag("layout_toggle_button")
        ) {
            Icon(
                imageVector = if (isGridView) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                contentDescription = stringResource(R.string.toggle_layout_view),
                tint = TextSecondary
            )
        }

        IconButton(
            onClick = onOpenFileClick,
            modifier = Modifier.testTag("open_file_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.FileOpen,
                contentDescription = stringResource(R.string.open_video_file),
                tint = TextSecondary
            )
        }

        IconButton(
            onClick = onSortClick,
            modifier = Modifier.testTag("sort_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.Sort,
                contentDescription = stringResource(R.string.sort_by),
                tint = ElectricCyan
            )
        }

        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier.testTag("settings_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.Settings,
                contentDescription = stringResource(R.string.settings_title),
                tint = TextPrimary
            )
        }
    }
}

@Composable
fun SearchCapsule(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DeepNavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_videos_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    cursorBrush = SolidColor(ElectricCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_videos_input")
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.clear_search),
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .clickable { onQueryChange("") }
                        .testTag("clear_search_button")
                )
            }
        }
    }
}

@Composable
private fun LibraryTabRow(
    activeTab: LibraryTab,
    folderCount: Int,
    videoCount: Int,
    onSelectTab: (LibraryTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DeepNavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val foldersSelected = activeTab == LibraryTab.FOLDERS
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectTab(LibraryTab.FOLDERS) }
                    .testTag("tab_folders"),
                color = if (foldersSelected) ElevatedNavy else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Folder,
                        contentDescription = null,
                        tint = if (foldersSelected) ElectricCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${stringResource(R.string.tab_folders)} ($folderCount)",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (foldersSelected) TextPrimary else TextSecondary
                    )
                }
            }

            val allSelected = activeTab == LibraryTab.ALL_VIDEOS
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectTab(LibraryTab.ALL_VIDEOS) }
                    .testTag("tab_all_videos"),
                color = if (allSelected) ElevatedNavy else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VideoLibrary,
                        contentDescription = null,
                        tint = if (allSelected) ElectricCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${stringResource(R.string.tab_all_videos)} ($videoCount)",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (allSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionRequestView(
    onGrantPermission: () -> Unit,
    onPickFile: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_cinema),
                contentDescription = stringResource(R.string.permission_title),
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )

            Text(
                text = stringResource(R.string.permission_title),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = stringResource(R.string.permission_description),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onGrantPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("grant_permission_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricCyan,
                    contentColor = AmoledBlack
                )
            ) {
                Text(
                    text = stringResource(R.string.grant_permission),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onPickFile,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("pick_video_directly_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Icon(
                    imageVector = Icons.Rounded.FileOpen,
                    contentDescription = null,
                    tint = ElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.pick_video_directly),
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
            }
        }
    }
}

@Composable
private fun EmptyLibraryView(
    isSearchEmpty: Boolean,
    onAction: () -> Unit,
    onRescan: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 380.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_cinema),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth(0.65f)
                    .clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                text = stringResource(
                    if (isSearchEmpty) R.string.empty_search_title else R.string.empty_library_title
                ),
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(
                    if (isSearchEmpty) R.string.empty_search_subtitle else R.string.empty_library_subtitle
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = AmoledBlack
                    ),
                    modifier = Modifier.testTag("empty_primary_action")
                ) {
                    Text(
                        text = stringResource(
                            if (isSearchEmpty) R.string.clear_search else R.string.pick_video_directly
                        ),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                if (!isSearchEmpty) {
                    OutlinedButton(
                        onClick = onRescan,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CardOutline)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.refresh_library),
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}
