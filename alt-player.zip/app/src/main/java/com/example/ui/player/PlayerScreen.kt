package com.example.ui.player

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.drawable.Icon as AndroidIcon
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.compose.ContentFrame
import com.example.R
import com.example.data.DefaultOrientation
import com.example.data.ResumeBehavior
import com.example.data.VideoItem
import com.example.data.formatDuration
import com.example.player.ActivePlayerBridge
import com.example.player.AspectMode
import com.example.player.AudioTrackOption
import com.example.player.BackgroundPlaybackService
import com.example.player.DecoderMode
import com.example.player.ExternalSubtitleTrack
import com.example.player.GestureFeedback
import com.example.player.LoopMode
import com.example.player.PlayerMath
import com.example.player.SleepTimerOption
import com.example.player.SrtSubtitleParser
import com.example.player.SubtitleSelection
import com.example.player.SubtitleStyleConfig
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class DragMode {
    NONE,
    PINCH_ZOOM,
    HORIZONTAL_SEEK,
    BRIGHTNESS,
    VOLUME
}

private const val ACTION_PIP_CONTROL = "com.example.player.PIP_CONTROL"
private const val EXTRA_PIP_COMMAND = "pip_command"
private const val PIP_CMD_PLAY_PAUSE = 1
private const val PIP_CMD_REWIND = 2
private const val PIP_CMD_FORWARD = 3

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playlist: List<VideoItem>,
    initialIndex: Int,
    resumeBehavior: ResumeBehavior,
    defaultOrientation: DefaultOrientation,
    autoLoadSrt: Boolean,
    subtitleStyle: SubtitleStyleConfig,
    isInPipMode: Boolean,
    getResumePositionMs: (Uri) -> Long,
    findMatchingSrtUri: suspend (VideoItem) -> Uri?,
    onUpdateSubtitleStyle: (SubtitleStyleConfig) -> Unit,
    onSaveProgress: (Uri, Long, Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val coroutineScope = rememberCoroutineScope()

    var currentIndex by remember(playlist, initialIndex) {
        mutableIntStateOf(initialIndex.coerceIn(0, (playlist.size - 1).coerceAtLeast(0)))
    }
    val currentVideo = playlist.getOrNull(currentIndex) ?: run {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    // Core Player Pro states
    var decoderMode by remember { mutableStateOf(DecoderMode.HW) }
    var pendingDecoderRestorePosMs by remember { mutableStateOf<Long?>(null) }
    var pendingDecoderRestorePlay by remember { mutableStateOf(true) }

    var isPlaying by remember { mutableStateOf(false) }
    var durationMs by remember { mutableLongStateOf(currentVideo.durationMs) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }
    var videoDimensions by remember { mutableStateOf(Pair(16, 9)) }
    var audioSessionId by remember { mutableIntStateOf(C.AUDIO_SESSION_ID_UNSET) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var lockedHintVisible by remember { mutableStateOf(false) }
    var aspectMode by remember { mutableStateOf(AspectMode.FIT) }
    var statusToastLabel by remember { mutableStateOf<String?>(null) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    // Pinch-to-Zoom & Pan states
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    // Background Play & Quick-Tools states
    var backgroundPlayEnabled by remember { mutableStateOf(false) }
    var quickToolsExpanded by remember { mutableStateOf(false) }
    var audioBoostPercent by remember { mutableIntStateOf(100) }
    var sleepTimerOption by remember { mutableStateOf(SleepTimerOption.OFF) }
    var sleepRemainingSeconds by remember { mutableLongStateOf(0L) }
    var loopMode by remember { mutableStateOf(LoopMode.OFF) }
    var abStartMs by remember { mutableStateOf<Long?>(null) }
    var abEndMs by remember { mutableStateOf<Long?>(null) }

    // Audio & Subtitles states
    var audioTracks by remember { mutableStateOf<List<AudioTrackOption>>(emptyList()) }
    var embeddedSubtitles by remember { mutableStateOf<List<SubtitleSelection.Embedded>>(emptyList()) }
    val externalSubtitles = remember { mutableStateListOf<ExternalSubtitleTrack>() }
    var activeExternalSubId by remember { mutableStateOf<String?>(null) }
    var subtitlesDisabled by remember { mutableStateOf(false) }
    var embeddedCueText by remember { mutableStateOf("") }
    var subtitleOffsetMs by remember { mutableLongStateOf(0L) }

    var showTrackSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var pendingAskResumeMs by remember { mutableStateOf<Long?>(null) }

    var gestureFeedback by remember { mutableStateOf<GestureFeedback?>(null) }
    var containerSize by remember { mutableStateOf(IntSize.Zero) }

    // Build ExoPlayer keyed on decoderMode (HW vs SW fallback)
    val exoPlayer = remember(decoderMode) {
        val trackSelector = DefaultTrackSelector(context)
        val renderersFactory = DefaultRenderersFactory(context).apply {
            if (decoderMode == DecoderMode.SW) {
                setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                setMediaCodecSelector { mimeType, requiresSecureDecoder, requiresTunnelingDecoder ->
                    val all = MediaCodecSelector.DEFAULT.getDecoderInfos(
                        mimeType,
                        requiresSecureDecoder,
                        requiresTunnelingDecoder
                    )
                    val swOnly = all.filter { info ->
                        !info.hardwareAccelerated ||
                            info.softwareOnly ||
                            info.name.startsWith("OMX.google.", ignoreCase = true) ||
                            info.name.startsWith("c2.android.", ignoreCase = true)
                    }
                    swOnly.ifEmpty { all }
                }
            }
        }
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setRenderersFactory(renderersFactory)
            .build()
    }

    // Notification permission launcher for Android 13+ Background Audio Play
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        backgroundPlayEnabled = true
        statusToastLabel = if (granted) {
            "Background Play Enabled"
        } else {
            "Background Audio On (Notification Hidden)"
        }
    }

    // Brightness & Volume state
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volumeFraction by remember {
        mutableFloatStateOf(
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume.toFloat()
        )
    }
    var brightnessFraction by remember {
        val initial = activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.5f
        mutableFloatStateOf(initial)
    }

    // Track double-tap accumulation
    var lastDoubleTapTimeMs by remember { mutableLongStateOf(0L) }
    var accumulatedTapDeltaSec by remember { mutableIntStateOf(0) }
    var lastTapForward by remember { mutableStateOf(true) }

    val pipSupported = remember(activity) {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            activity?.packageManager?.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) == true
    }

    fun updatePipParams(playing: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || activity == null || !pipSupported) return
        val (num, den) = PlayerMath.clampPipAspectRatio(videoDimensions.first, videoDimensions.second)
        val rewindAction = createPipRemoteAction(
            context = context,
            requestCode = 201,
            iconRes = android.R.drawable.ic_media_rew,
            title = "Rewind 10s",
            command = PIP_CMD_REWIND
        )
        val playPauseAction = createPipRemoteAction(
            context = context,
            requestCode = 202,
            iconRes = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            title = if (playing) "Pause" else "Play",
            command = PIP_CMD_PLAY_PAUSE
        )
        val forwardAction = createPipRemoteAction(
            context = context,
            requestCode = 203,
            iconRes = android.R.drawable.ic_media_ff,
            title = "Forward 10s",
            command = PIP_CMD_FORWARD
        )
        val builder = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(num, den))
            .setActions(listOf(rewindAction, playPauseAction, forwardAction))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(false)
        }
        runCatching { activity.setPictureInPictureParams(builder.build()) }
    }

    // BroadcastReceiver for PiP remote action buttons
    DisposableEffect(exoPlayer, pipSupported) {
        if (!pipSupported) {
            onDispose { }
        } else {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    if (intent?.action != ACTION_PIP_CONTROL) return
                    when (intent.getIntExtra(EXTRA_PIP_COMMAND, 0)) {
                        PIP_CMD_PLAY_PAUSE -> {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        }
                        PIP_CMD_REWIND -> {
                            val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(target)
                        }
                        PIP_CMD_FORWARD -> {
                            val maxDur = exoPlayer.duration.takeIf { it > 0L } ?: Long.MAX_VALUE
                            val target = (exoPlayer.currentPosition + 10_000L).coerceAtMost(maxDur)
                            exoPlayer.seekTo(target)
                        }
                    }
                }
            }
            ContextCompat.registerReceiver(
                context,
                receiver,
                IntentFilter(ACTION_PIP_CONTROL),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            onDispose {
                runCatching { context.unregisterReceiver(receiver) }
            }
        }
    }

    // Keep PiP actions synced with Play/Pause state and video aspect ratio
    LaunchedEffect(isPlaying, videoDimensions, pipSupported) {
        updatePipParams(isPlaying)
    }

    // Keep screen on & hide system bars while in PlayerScreen
    DisposableEffect(activity, view) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())

        onDispose {
            BackgroundPlaybackService.stop(context)
            ActivePlayerBridge.player = null
            ActivePlayerBridge.onStopBackground = null
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window?.attributes = window?.attributes?.apply {
                screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Sync ActivePlayerBridge for BackgroundPlaybackService
    LaunchedEffect(exoPlayer, currentVideo.title) {
        ActivePlayerBridge.player = exoPlayer
        ActivePlayerBridge.title = currentVideo.title
        ActivePlayerBridge.onStopBackground = {
            backgroundPlayEnabled = false
        }
    }

    // Apply LoudnessEnhancer Audio Boost (100%..200%)
    DisposableEffect(exoPlayer, audioSessionId, audioBoostPercent) {
        val sessionId = audioSessionId.takeIf { it != C.AUDIO_SESSION_ID_UNSET && it != 0 }
            ?: exoPlayer.audioSessionId.takeIf { it != C.AUDIO_SESSION_ID_UNSET && it != 0 }
        val enhancer = if (sessionId != null) {
            runCatching {
                LoudnessEnhancer(sessionId).apply {
                    val gainMb = PlayerMath.computeLoudnessGainMb(audioBoostPercent)
                    setTargetGain(gainMb)
                    enabled = audioBoostPercent > 100
                }
            }.getOrNull()
        } else {
            null
        }
        onDispose {
            runCatching { enhancer?.release() }
        }
    }

    // Sleep Timer countdown
    LaunchedEffect(sleepTimerOption) {
        val mins = sleepTimerOption.minutes
        if (mins == null || mins <= 0) {
            sleepRemainingSeconds = 0L
        } else {
            var remaining = mins * 60L
            sleepRemainingSeconds = remaining
            while (remaining > 0L) {
                delay(1000L)
                remaining -= 1L
                sleepRemainingSeconds = remaining
            }
            exoPlayer.pause()
            sleepTimerOption = SleepTimerOption.OFF
            controlsVisible = true
            statusToastLabel = "Sleep Timer Paused Playback"
        }
    }

    // Block accidental back press when controls are locked; save progress on back when unlocked
    BackHandler {
        if (isLocked) {
            lockedHintVisible = true
        } else {
            onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            onBack()
        }
    }

    // Apply default orientation preference on launch
    LaunchedEffect(defaultOrientation) {
        when (defaultOrientation) {
            DefaultOrientation.LANDSCAPE ->
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            DefaultOrientation.PORTRAIT ->
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            DefaultOrientation.AUTO ->
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Load current video into ExoPlayer whenever currentVideo or decoderMode changes
    LaunchedEffect(currentVideo.uri, exoPlayer) {
        val decoderPos = pendingDecoderRestorePosMs
        val decoderPlay = pendingDecoderRestorePlay
        val isDecoderSwitch = decoderPos != null
        pendingDecoderRestorePosMs = null

        val startPos: Long
        val autoPlay: Boolean

        if (isDecoderSwitch) {
            startPos = decoderPos ?: 0L
            autoPlay = decoderPlay
        } else {
            abStartMs = null
            abEndMs = null
            subtitleOffsetMs = 0L
            embeddedCueText = ""
            activeExternalSubId = null

            val resumeMs = getResumePositionMs(currentVideo.uri)
            val hasValidResume = resumeMs > 3_000L &&
                (currentVideo.durationMs <= 0L || resumeMs < currentVideo.durationMs - 5_000L)

            startPos = when {
                !hasValidResume -> 0L
                resumeBehavior == ResumeBehavior.ALWAYS_RESUME -> resumeMs
                resumeBehavior == ResumeBehavior.START_OVER -> 0L
                else -> {
                    pendingAskResumeMs = resumeMs
                    0L
                }
            }
            autoPlay = pendingAskResumeMs == null
        }

        exoPlayer.setMediaItem(MediaItem.fromUri(currentVideo.uri), startPos)
        exoPlayer.repeatMode = loopMode.exoRepeatMode
        exoPlayer.prepare()
        exoPlayer.setPlaybackSpeed(playbackSpeed)
        exoPlayer.playWhenReady = autoPlay

        if (autoLoadSrt && !isDecoderSwitch) {
            val matchingSrt = findMatchingSrtUri(currentVideo)
            if (matchingSrt != null) {
                val parsed = SrtSubtitleParser.loadFromUri(context, matchingSrt)
                if (parsed != null && parsed.cues.isNotEmpty()) {
                    if (externalSubtitles.none { it.id == parsed.id }) {
                        externalSubtitles.add(parsed)
                    }
                    activeExternalSubId = parsed.id
                    subtitlesDisabled = false
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                    statusToastLabel = "Auto-loaded ${parsed.displayName}"
                }
            }
        }
    }

    // Sync loopMode with ExoPlayer repeatMode
    LaunchedEffect(exoPlayer, loopMode) {
        exoPlayer.repeatMode = loopMode.exoRepeatMode
    }

    // Player listener for play/pause state, tracks, video size, audio session, and embedded cues
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoDimensions = videoSize.width to videoSize.height
                }
            }

            override fun onAudioSessionIdChanged(sessionId: Int) {
                audioSessionId = sessionId
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (exoPlayer.duration != C.TIME_UNSET && exoPlayer.duration > 0L) {
                    durationMs = exoPlayer.duration
                }
                if (playbackState == Player.STATE_ENDED) {
                    onSaveProgress(currentVideo.uri, exoPlayer.duration, exoPlayer.duration)
                    if (sleepTimerOption == SleepTimerOption.END_OF_VIDEO) {
                        exoPlayer.pause()
                        sleepTimerOption = SleepTimerOption.OFF
                        controlsVisible = true
                        statusToastLabel = "Sleep Timer Finished"
                        return
                    }
                    when (loopMode) {
                        LoopMode.REPEAT_ONE -> Unit // handled natively by ExoPlayer
                        LoopMode.REPEAT_FOLDER -> {
                            if (playlist.size > 1) {
                                currentIndex = (currentIndex + 1) % playlist.size
                            }
                        }
                        LoopMode.OFF -> {
                            if (currentIndex < playlist.lastIndex) {
                                currentIndex += 1
                            } else {
                                controlsVisible = true
                            }
                        }
                    }
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                audioTracks = extractAudioTracks(tracks)
                embeddedSubtitles = extractEmbeddedSubtitles(tracks)
            }

            override fun onCues(cueGroup: CueGroup) {
                embeddedCueText = cueGroup.cues
                    .mapNotNull { it.text?.toString()?.trim() }
                    .filter { it.isNotEmpty() }
                    .joinToString("\n")
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Lifecycle handling for Background Play & PiP
    val updatedInPip by rememberUpdatedState(isInPipMode)
    val updatedBgPlay by rememberUpdatedState(backgroundPlayEnabled)
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    BackgroundPlaybackService.stop(context)
                }
                Lifecycle.Event.ON_PAUSE -> {
                    onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                    if (!updatedInPip && !updatedBgPlay) {
                        exoPlayer.pause()
                    }
                }
                Lifecycle.Event.ON_STOP -> {
                    if (!updatedInPip && updatedBgPlay && exoPlayer.isPlaying) {
                        BackgroundPlaybackService.start(context)
                    } else if (!updatedInPip && !updatedBgPlay) {
                        exoPlayer.pause()
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Smooth position polling + A-B loop + periodic progress save
    LaunchedEffect(exoPlayer, currentVideo.uri, abStartMs, abEndMs) {
        var tickCount = 0
        while (true) {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            if (!isScrubbing) {
                currentPositionMs = pos
            }
            if (exoPlayer.duration != C.TIME_UNSET && exoPlayer.duration > 0L) {
                durationMs = exoPlayer.duration
            }
            val startMarker = abStartMs
            val endMarker = abEndMs
            if (startMarker != null && endMarker != null && endMarker > startMarker && pos >= endMarker) {
                exoPlayer.seekTo(startMarker)
                currentPositionMs = startMarker
            }
            tickCount++
            if (tickCount % 25 == 0 && exoPlayer.isPlaying) {
                onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            }
            delay(if (abEndMs != null) 100L else 200L)
        }
    }

    // Auto-hide controls after 3.5 seconds while playing (keep visible while quickToolsExpanded is toggled on)
    LaunchedEffect(controlsVisible, isPlaying, isLocked, showTrackSheet, showSpeedSheet, quickToolsExpanded) {
        if (controlsVisible && isPlaying && !isLocked && !showTrackSheet && !showSpeedSheet && !quickToolsExpanded) {
            delay(3500L)
            controlsVisible = false
        }
    }

    // Auto-hide locked hint
    LaunchedEffect(lockedHintVisible) {
        if (lockedHintVisible) {
            delay(2200L)
            lockedHintVisible = false
        }
    }

    // Auto-hide centered status toast
    LaunchedEffect(statusToastLabel) {
        if (statusToastLabel != null) {
            delay(1500L)
            statusToastLabel = null
        }
    }

    // Auto-hide double-tap feedback
    LaunchedEffect(gestureFeedback) {
        if (gestureFeedback is GestureFeedback.DoubleTapSeek) {
            delay(900L)
            gestureFeedback = null
        }
    }

    // SRT document picker
    val srtPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val parsed = SrtSubtitleParser.loadFromUri(context, uri)
                if (parsed != null) {
                    val existingIdx = externalSubtitles.indexOfFirst { it.id == parsed.id }
                    if (existingIdx >= 0) {
                        externalSubtitles[existingIdx] = parsed
                    } else {
                        externalSubtitles.add(parsed)
                    }
                    activeExternalSubId = parsed.id
                    subtitlesDisabled = false
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                }
            }
        }
    }

    // Compute active subtitle text (with subtitleOffsetMs sync applied)
    val activeExternalTrack = externalSubtitles.find { it.id == activeExternalSubId }
    val syncedPositionMs = (currentPositionMs - subtitleOffsetMs).coerceAtLeast(0L)
    val activeSubtitleText = when {
        subtitlesDisabled -> ""
        activeExternalTrack != null -> SrtSubtitleParser.findActiveCues(
            activeExternalTrack.cues,
            syncedPositionMs
        )
        else -> embeddedCueText
    }

    val updatedIsLocked by rememberUpdatedState(isLocked)
    val updatedIsPlaying by rememberUpdatedState(isPlaying)
    val updatedDuration by rememberUpdatedState(durationMs)
    val updatedExoPlayer by rememberUpdatedState(exoPlayer)
    val viewConfig = LocalViewConfiguration.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .onSizeChanged { containerSize = it }
            // Tap & Double-tap gesture detector
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (isInPipMode) return@detectTapGestures
                        if (updatedIsLocked) {
                            lockedHintVisible = !lockedHintVisible
                        } else {
                            controlsVisible = !controlsVisible
                        }
                    },
                    onDoubleTap = { offset ->
                        if (isInPipMode) return@detectTapGestures
                        if (updatedIsLocked) {
                            lockedHintVisible = true
                            return@detectTapGestures
                        }
                        val width = containerSize.width.toFloat().coerceAtLeast(1f)
                        val isLeft = offset.x < width * 0.42f
                        val isRight = offset.x > width * 0.58f

                        if (!isLeft && !isRight) {
                            if (updatedIsPlaying) updatedExoPlayer.pause() else updatedExoPlayer.play()
                            return@detectTapGestures
                        }

                        val isForward = isRight
                        val now = System.currentTimeMillis()
                        if (now - lastDoubleTapTimeMs < 950L && lastTapForward == isForward) {
                            accumulatedTapDeltaSec += 10
                        } else {
                            accumulatedTapDeltaSec = 10
                        }
                        lastDoubleTapTimeMs = now
                        lastTapForward = isForward

                        val deltaMs = if (isForward) 10_000L else -10_000L
                        val maxDur = updatedDuration.takeIf { it > 0L } ?: Long.MAX_VALUE
                        val newPos = (updatedExoPlayer.currentPosition + deltaMs).coerceIn(0L, maxDur)
                        updatedExoPlayer.seekTo(newPos)
                        currentPositionMs = newPos
                        gestureFeedback = GestureFeedback.DoubleTapSeek(
                            isForward = isForward,
                            totalDeltaSeconds = accumulatedTapDeltaSec
                        )
                    }
                )
            }
            // Pinch-to-Zoom & Pan + Single-finger MX Vertical/Horizontal swipe detector
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (updatedIsLocked || isInPipMode) return@awaitEachGesture

                    val startX = down.position.x
                    var dragMode = DragMode.NONE
                    var cumulativeDx = 0f
                    var cumulativeDy = 0f

                    val initialPosMs = updatedExoPlayer.currentPosition.coerceAtLeast(0L)
                    var seekTargetMs = initialPosMs

                    val currentBrightness = activity?.window?.attributes?.screenBrightness
                        ?.takeIf { it in 0f..1f } ?: brightnessFraction
                    var activeBrightness = currentBrightness

                    val currentVolStep = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    var activeVol = currentVolStep.toFloat() / maxVolume.toFloat()

                    val slop = viewConfig.touchSlop

                    while (true) {
                        val event = awaitPointerEvent()
                        val pressedChanges = event.changes.filter { it.pressed }

                        if (pressedChanges.isEmpty()) {
                            if (dragMode == DragMode.HORIZONTAL_SEEK) {
                                updatedExoPlayer.seekTo(seekTargetMs)
                                currentPositionMs = seekTargetMs
                            }
                            if (dragMode != DragMode.NONE) {
                                gestureFeedback = null
                            }
                            break
                        }

                        // Switch into 2-finger pinch-to-zoom & pan whenever 2+ fingers are down
                        if (pressedChanges.size >= 2) {
                            dragMode = DragMode.PINCH_ZOOM
                            val zoomChange = event.calculateZoom()
                            val panChange = event.calculatePan()
                            val nextScale = PlayerMath.clampZoomScale(zoomScale * zoomChange)
                            zoomScale = nextScale

                            val maxOffsetX = (containerSize.width * (nextScale - 1f).coerceAtLeast(0f)) / 2f + 160f
                            val maxOffsetY = (containerSize.height * (nextScale - 1f).coerceAtLeast(0f)) / 2f + 160f
                            val nextPan = panOffset + panChange
                            panOffset = Offset(
                                x = nextPan.x.coerceIn(-maxOffsetX, maxOffsetX),
                                y = nextPan.y.coerceIn(-maxOffsetY, maxOffsetY)
                            )

                            gestureFeedback = GestureFeedback.PinchZoom((nextScale * 100f).roundToInt())
                            event.changes.forEach { it.consume() }
                            continue
                        }

                        if (dragMode == DragMode.PINCH_ZOOM) {
                            // Remaining 1 finger after lifting second finger — wait until release
                            continue
                        }

                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) {
                            if (dragMode == DragMode.HORIZONTAL_SEEK) {
                                updatedExoPlayer.seekTo(seekTargetMs)
                                currentPositionMs = seekTargetMs
                            }
                            if (dragMode != DragMode.NONE) {
                                gestureFeedback = null
                            }
                            break
                        }

                        val delta = change.positionChange()
                        cumulativeDx += delta.x
                        cumulativeDy += delta.y

                        if (dragMode == DragMode.NONE) {
                            val absX = abs(cumulativeDx)
                            val absY = abs(cumulativeDy)
                            if (absX > slop || absY > slop) {
                                dragMode = if (absX > absY) {
                                    DragMode.HORIZONTAL_SEEK
                                } else if (startX < containerSize.width / 2f) {
                                    DragMode.BRIGHTNESS
                                } else {
                                    DragMode.VOLUME
                                }
                            }
                        }

                        when (dragMode) {
                            DragMode.HORIZONTAL_SEEK -> {
                                change.consume()
                                val widthPx = containerSize.width.toFloat().coerceAtLeast(1f)
                                val totalSeekSpanMs = if (updatedDuration > 0L) {
                                    minOf(120_000L, maxOf(45_000L, updatedDuration / 2L))
                                } else {
                                    60_000L
                                }
                                val offsetFromStart = change.position.x - startX
                                val deltaMs = ((offsetFromStart / widthPx) * totalSeekSpanMs).toLong()
                                val maxDur = updatedDuration.takeIf { it > 0L } ?: Long.MAX_VALUE
                                seekTargetMs = (initialPosMs + deltaMs).coerceIn(0L, maxDur)
                                gestureFeedback = GestureFeedback.HorizontalSeek(
                                    targetMs = seekTargetMs,
                                    deltaMs = seekTargetMs - initialPosMs,
                                    durationMs = updatedDuration
                                )
                            }

                            DragMode.BRIGHTNESS -> {
                                change.consume()
                                val heightPx = (containerSize.height * 0.65f).coerceAtLeast(1f)
                                val deltaNorm = -delta.y / heightPx
                                activeBrightness = (activeBrightness + deltaNorm).coerceIn(0.01f, 1.0f)
                                brightnessFraction = activeBrightness
                                activity?.window?.let { w ->
                                    val attrs = w.attributes
                                    attrs.screenBrightness = activeBrightness
                                    w.attributes = attrs
                                }
                                gestureFeedback = GestureFeedback.Brightness(
                                    percent = (activeBrightness * 100f).roundToInt()
                                )
                            }

                            DragMode.VOLUME -> {
                                change.consume()
                                val heightPx = (containerSize.height * 0.65f).coerceAtLeast(1f)
                                val deltaNorm = -delta.y / heightPx
                                activeVol = (activeVol + deltaNorm).coerceIn(0f, 1f)
                                volumeFraction = activeVol
                                val targetStep = (activeVol * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStep, 0)
                                gestureFeedback = GestureFeedback.Volume(
                                    percent = (activeVol * 100f).roundToInt(),
                                    isMuted = targetStep == 0
                                )
                            }

                            DragMode.PINCH_ZOOM, DragMode.NONE -> Unit
                        }
                    }
                }
            }
    ) {
        // Video Surface via Media3 ContentFrame with Pinch-to-Zoom & Pan
        ContentFrame(
            player = exoPlayer,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                },
            contentScale = aspectMode.contentScale
        )

        // Subtitles Overlay (Styled & Synced)
        if (activeSubtitleText.isNotEmpty() && !isInPipMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        start = 24.dp,
                        end = 24.dp,
                        bottom = if (controlsVisible && !isLocked) 132.dp else 36.dp
                    )
                    .navigationBarsPadding()
            ) {
                Surface(
                    color = AmoledBlack.copy(alpha = subtitleStyle.bgOpacity),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = activeSubtitleText,
                        fontSize = subtitleStyle.fontSize.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = subtitleStyle.textColor.color,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("subtitle_overlay_text")
                    )
                }
            }
        }

        // Gesture Feedback HUD (Brightness / Volume / Seek / Double-Tap / PinchZoom / Toast)
        if (!isInPipMode) {
            GestureFeedbackHud(
                feedback = gestureFeedback,
                statusToastLabel = statusToastLabel,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Controls Overlay (when unlocked and not in PiP)
        AnimatedVisibility(
            visible = controlsVisible && !isLocked && !isInPipMode,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            PlayerControlsOverlay(
                title = currentVideo.title,
                resolutionLabel = currentVideo.resolutionLabel,
                extension = currentVideo.extension,
                isPlaying = isPlaying,
                currentPositionMs = if (isScrubbing) scrubPositionMs else currentPositionMs,
                durationMs = durationMs,
                playbackSpeed = playbackSpeed,
                aspectMode = aspectMode,
                decoderMode = decoderMode,
                zoomScale = zoomScale,
                pipSupported = pipSupported,
                backgroundPlayEnabled = backgroundPlayEnabled,
                quickToolsExpanded = quickToolsExpanded,
                audioBoostPercent = audioBoostPercent,
                sleepTimerOption = sleepTimerOption,
                sleepRemainingSeconds = sleepRemainingSeconds,
                loopMode = loopMode,
                abStartMs = abStartMs,
                abEndMs = abEndMs,
                hasPrevious = currentIndex > 0,
                hasNext = currentIndex < playlist.lastIndex,
                onBack = {
                    onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                    onBack()
                },
                onToggleDecoder = {
                    pendingDecoderRestorePosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                    pendingDecoderRestorePlay = exoPlayer.isPlaying || exoPlayer.playWhenReady
                    val nextMode = if (decoderMode == DecoderMode.HW) DecoderMode.SW else DecoderMode.HW
                    decoderMode = nextMode
                    statusToastLabel = "${nextMode.label} Decoder • ${nextMode.fullName}"
                },
                onToggleBackgroundPlay = {
                    if (backgroundPlayEnabled) {
                        backgroundPlayEnabled = false
                        BackgroundPlaybackService.stop(context)
                        statusToastLabel = "Background Play Off"
                    } else if (
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        backgroundPlayEnabled = true
                        statusToastLabel = "Background Play Enabled"
                    }
                },
                onEnterPip = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null && pipSupported) {
                        controlsVisible = false
                        quickToolsExpanded = false
                        updatePipParams(exoPlayer.isPlaying)
                        val (num, den) = PlayerMath.clampPipAspectRatio(
                            videoDimensions.first,
                            videoDimensions.second
                        )
                        val params = PictureInPictureParams.Builder()
                            .setAspectRatio(Rational(num, den))
                            .build()
                        activity.enterPictureInPictureMode(params)
                    }
                },
                onToggleQuickTools = {
                    quickToolsExpanded = !quickToolsExpanded
                },
                onOpenTracks = { showTrackSheet = true },
                onOpenSpeed = { showSpeedSheet = true },
                onCycleAspect = {
                    aspectMode = aspectMode.next()
                    zoomScale = 1.0f
                    panOffset = Offset.Zero
                    statusToastLabel = aspectMode.label
                },
                onResetZoom = {
                    zoomScale = 1.0f
                    panOffset = Offset.Zero
                    statusToastLabel = "Zoom Reset (100%)"
                },
                onToggleRotation = {
                    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                    activity?.requestedOrientation = if (isLandscape) {
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                },
                onLock = {
                    isLocked = true
                    controlsVisible = false
                    quickToolsExpanded = false
                    lockedHintVisible = true
                },
                onPrevious = {
                    if (currentIndex > 0) {
                        onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                        currentIndex -= 1
                    }
                },
                onNext = {
                    if (currentIndex < playlist.lastIndex) {
                        onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                        currentIndex += 1
                    }
                },
                onRewind10 = {
                    val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                    exoPlayer.seekTo(target)
                    currentPositionMs = target
                },
                onForward10 = {
                    val maxDur = durationMs.takeIf { it > 0L } ?: Long.MAX_VALUE
                    val target = (exoPlayer.currentPosition + 10_000L).coerceAtMost(maxDur)
                    exoPlayer.seekTo(target)
                    currentPositionMs = target
                },
                onTogglePlayPause = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                },
                onScrubChange = { pos ->
                    isScrubbing = true
                    scrubPositionMs = pos
                },
                onScrubFinished = {
                    exoPlayer.seekTo(scrubPositionMs)
                    currentPositionMs = scrubPositionMs
                    isScrubbing = false
                },
                onSelectAudioBoost = { pct ->
                    audioBoostPercent = pct.coerceIn(
                        PlayerMath.MIN_AUDIO_BOOST_PERCENT,
                        PlayerMath.MAX_AUDIO_BOOST_PERCENT
                    )
                    statusToastLabel = "Audio Boost: $audioBoostPercent%"
                },
                onSelectSleepTimer = { option ->
                    sleepTimerOption = option
                    statusToastLabel = if (option == SleepTimerOption.OFF) {
                        "Sleep Timer Off"
                    } else {
                        "Sleep Timer: ${option.label}"
                    }
                },
                onCycleLoopMode = {
                    loopMode = loopMode.next()
                    statusToastLabel = "Loop: ${loopMode.label}"
                },
                onToggleAbRepeat = {
                    val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                    val start = abStartMs
                    if (start == null) {
                        abStartMs = pos
                        abEndMs = null
                        statusToastLabel = "A-B Marker A: ${formatDuration(pos)}"
                    } else if (abEndMs == null) {
                        if (pos > start + 500L) {
                            abEndMs = pos
                            exoPlayer.seekTo(start)
                            statusToastLabel = "A-B Loop: ${formatDuration(start)}–${formatDuration(pos)}"
                        } else {
                            abStartMs = pos
                            statusToastLabel = "Set Marker B after ${formatDuration(start)}"
                        }
                    }
                },
                onClearAbRepeat = {
                    abStartMs = null
                    abEndMs = null
                    statusToastLabel = "A-B Repeat Cleared"
                }
            )
        }

        // Locked State Unlock Pill
        AnimatedVisibility(
            visible = isLocked && lockedHintVisible && !isInPipMode,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopStart)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(18.dp)
        ) {
            Surface(
                onClick = {
                    isLocked = false
                    lockedHintVisible = false
                    controlsVisible = true
                },
                color = AmoledBlack.copy(alpha = 0.82f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("unlock_screen_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = stringResource(R.string.unlock_screen),
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.screen_locked_hint),
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )
                }
            }
        }
    }

    if (showTrackSheet) {
        TrackSelectorSheet(
            audioTracks = audioTracks,
            embeddedSubtitles = embeddedSubtitles,
            externalSubtitles = externalSubtitles,
            selectedExternalId = activeExternalSubId,
            subtitlesDisabled = subtitlesDisabled,
            subtitleOffsetMs = subtitleOffsetMs,
            subtitleStyle = subtitleStyle,
            onSelectAudioTrack = { option ->
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(
                        TrackSelectionOverride(option.trackGroup.mediaTrackGroup, option.trackIndex)
                    )
                    .build()
                showTrackSheet = false
            },
            onSelectSubtitlesOff = {
                activeExternalSubId = null
                subtitlesDisabled = true
                embeddedCueText = ""
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTrackSheet = false
            },
            onSelectEmbeddedSubtitle = { sub ->
                activeExternalSubId = null
                subtitlesDisabled = false
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(
                        TrackSelectionOverride(sub.trackGroup.mediaTrackGroup, sub.trackIndex)
                    )
                    .build()
                showTrackSheet = false
            },
            onSelectExternalSubtitle = { ext ->
                activeExternalSubId = ext.id
                subtitlesDisabled = false
                embeddedCueText = ""
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTrackSheet = false
            },
            onLoadExternalSrtClick = {
                srtPickerLauncher.launch(
                    arrayOf(
                        "application/x-subrip",
                        "text/plain",
                        "application/octet-stream",
                        "*/*"
                    )
                )
            },
            onAdjustSubtitleOffset = { deltaMs ->
                subtitleOffsetMs = PlayerMath.clampSubtitleOffsetMs(subtitleOffsetMs + deltaMs)
            },
            onResetSubtitleOffset = {
                subtitleOffsetMs = 0L
            },
            onUpdateSubtitleStyle = onUpdateSubtitleStyle,
            onDismiss = { showTrackSheet = false }
        )
    }

    if (showSpeedSheet) {
        SpeedSelectorSheet(
            currentSpeed = playbackSpeed,
            onSelectSpeed = { speed ->
                playbackSpeed = speed
                exoPlayer.setPlaybackSpeed(speed)
            },
            onDismiss = { showSpeedSheet = false }
        )
    }

    pendingAskResumeMs?.let { savedMs ->
        AlertDialog(
            onDismissRequest = {
                pendingAskResumeMs = null
                exoPlayer.playWhenReady = true
                exoPlayer.play()
            },
            containerColor = DeepNavySurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Text(
                    text = "Resume Playback?",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "Resume \"${currentVideo.title}\" from ${formatDuration(savedMs)} or start over?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        exoPlayer.seekTo(savedMs)
                        currentPositionMs = savedMs
                        pendingAskResumeMs = null
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = AmoledBlack
                    ),
                    modifier = Modifier.testTag("resume_prompt_confirm")
                ) {
                    Text("Resume from ${formatDuration(savedMs)}")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        exoPlayer.seekTo(0L)
                        currentPositionMs = 0L
                        pendingAskResumeMs = null
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                    },
                    modifier = Modifier.testTag("resume_prompt_start_over")
                ) {
                    Text("Start Over", color = TextSecondary)
                }
            }
        )
    }
}

private fun createPipRemoteAction(
    context: Context,
    requestCode: Int,
    iconRes: Int,
    title: String,
    command: Int
): RemoteAction {
    val intent = Intent(ACTION_PIP_CONTROL).apply {
        setPackage(context.packageName)
        putExtra(EXTRA_PIP_COMMAND, command)
    }
    val pendingIntent = PendingIntent.getBroadcast(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    return RemoteAction(
        AndroidIcon.createWithResource(context, iconRes),
        title,
        title,
        pendingIntent
    )
}

private fun extractAudioTracks(tracks: Tracks): List<AudioTrackOption> {
    val result = mutableListOf<AudioTrackOption>()
    var counter = 1
    tracks.groups.forEachIndexed { groupIdx, group ->
        if (group.type == C.TRACK_TYPE_AUDIO) {
            for (trackIdx in 0 until group.length) {
                if (!group.isTrackSupported(trackIdx)) continue
                val format = group.getTrackFormat(trackIdx)
                val langCode = format.language.orEmpty()
                val langName = if (langCode.isNotBlank() && langCode != "und") {
                    Locale.forLanguageTag(langCode).displayLanguage.replaceFirstChar { it.uppercase() }
                } else {
                    "Audio Track $counter"
                }
                val title = format.label?.takeIf { it.isNotBlank() } ?: langName
                val channels = when (format.channelCount) {
                    1 -> "Mono"
                    2 -> "Stereo"
                    6 -> "5.1"
                    8 -> "7.1"
                    else -> if (format.channelCount > 0) "${format.channelCount}ch" else ""
                }
                val codec = format.sampleMimeType?.substringAfter('/')?.uppercase().orEmpty()
                val detail = listOf(channels, codec).filter { it.isNotBlank() }.joinToString(" • ")

                result.add(
                    AudioTrackOption(
                        id = "${groupIdx}_$trackIdx",
                        label = title,
                        detail = detail,
                        isSelected = group.isTrackSelected(trackIdx),
                        trackGroup = group,
                        trackIndex = trackIdx
                    )
                )
                counter++
            }
        }
    }
    return result
}

private fun extractEmbeddedSubtitles(tracks: Tracks): List<SubtitleSelection.Embedded> {
    val result = mutableListOf<SubtitleSelection.Embedded>()
    var counter = 1
    tracks.groups.forEachIndexed { groupIdx, group ->
        if (group.type == C.TRACK_TYPE_TEXT) {
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val langCode = format.language.orEmpty()
                val langName = if (langCode.isNotBlank() && langCode != "und") {
                    Locale.forLanguageTag(langCode).displayLanguage.replaceFirstChar { it.uppercase() }
                } else {
                    ""
                }
                val label = format.label?.takeIf { it.isNotBlank() }
                    ?: langName.ifBlank { "Subtitle Track $counter" }
                result.add(
                    SubtitleSelection.Embedded(
                        id = "${groupIdx}_$trackIdx",
                        label = label,
                        language = langName,
                        isSelected = group.isTrackSelected(trackIdx),
                        trackGroup = group,
                        trackIndex = trackIdx
                    )
                )
                counter++
            }
        }
    }
    return result
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
