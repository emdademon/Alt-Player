package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.AppUpdateState
import com.example.data.formatFileSize
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CoralError
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedCharcoal
import com.example.ui.theme.ForestContainer
import com.example.ui.theme.LuminousMint
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnForestContainer
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TealEmeraldDeep
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AppUpdateDialog(
    updateState: AppUpdateState,
    onUpdateNow: () -> Unit,
    onInstallDownloaded: () -> Unit,
    onOpenInstallSettings: () -> Unit,
    onRetryCheck: () -> Unit,
    onDismiss: () -> Unit
) {
    if (updateState is AppUpdateState.Idle ||
        updateState is AppUpdateState.Checking ||
        updateState is AppUpdateState.UpToDate
    ) {
        return
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = updateState !is AppUpdateState.Downloading
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("app_update_dialog"),
            color = DeepNavySurface,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, LuminousMint.copy(alpha = 0.28f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (updateState) {
                    is AppUpdateState.UpdateAvailable -> {
                        UpdateAvailableContent(
                            state = updateState,
                            onUpdateNow = onUpdateNow,
                            onDismiss = onDismiss
                        )
                    }

                    is AppUpdateState.Downloading -> {
                        DownloadingUpdateContent(
                            state = updateState,
                            onHide = onDismiss
                        )
                    }

                    is AppUpdateState.ReadyToInstall -> {
                        ReadyToInstallContent(
                            state = updateState,
                            onInstallDownloaded = onInstallDownloaded,
                            onOpenInstallSettings = onOpenInstallSettings,
                            onDismiss = onDismiss
                        )
                    }

                    is AppUpdateState.Error -> {
                        UpdateErrorContent(
                            message = updateState.message,
                            onRetry = onRetryCheck,
                            onDismiss = onDismiss
                        )
                    }

                    else -> Unit
                }
            }
        }
    }
}

@Composable
private fun UpdateAvailableContent(
    state: AppUpdateState.UpdateAvailable,
    onUpdateNow: () -> Unit,
    onDismiss: () -> Unit
) {
    val release = state.release

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(listOf(TealEmeraldDeep, LuminousMint))
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.NewReleases,
                contentDescription = null,
                tint = ObsidianBlack,
                modifier = Modifier.size(24.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Update Available",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = release.releaseName,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            color = ForestContainer,
            shape = RoundedCornerShape(999.dp),
            border = BorderStroke(1.dp, LuminousMint.copy(alpha = 0.4f))
        ) {
            Text(
                text = "v${state.currentVersion} → v${release.versionTag}",
                style = MaterialTheme.typography.labelMedium,
                color = OnForestContainer,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }

        if (release.apkSizeBytes > 0L) {
            Surface(
                color = ElevatedCharcoal,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, SubtleBorder)
            ) {
                Text(
                    text = formatFileSize(release.apkSizeBytes),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ObsidianBlack,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 68.dp, max = 190.dp)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "WHAT'S NEW",
                style = MaterialTheme.typography.labelSmall,
                color = LuminousMint,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = release.releaseNotes,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onDismiss,
            colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary),
            modifier = Modifier.testTag("update_later_button")
        ) {
            Text("Later")
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.horizontalGradient(listOf(TealEmeraldDeep, LuminousMint))
                )
                .clickable(onClick = onUpdateNow)
                .padding(horizontal = 18.dp)
                .testTag("update_now_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Download,
                    contentDescription = null,
                    tint = ObsidianBlack,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Update Now",
                    style = MaterialTheme.typography.labelLarge,
                    color = ObsidianBlack,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun DownloadingUpdateContent(
    state: AppUpdateState.Downloading,
    onHide: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(ForestContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = LuminousMint,
                modifier = Modifier.size(22.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Downloading v${state.release.versionTag}",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Downloading APK package cleanly via Android DownloadManager",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
        }
    }

    val fraction = state.progressFraction
    if (fraction != null) {
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(999.dp)),
            color = LuminousMint,
            trackColor = SubtleBorder,
            strokeCap = StrokeCap.Round
        )
    } else {
        LinearProgressIndicator(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(999.dp)),
            color = LuminousMint,
            trackColor = SubtleBorder,
            strokeCap = StrokeCap.Round
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val percentLabel = fraction?.let { "${(it * 100).toInt()}%" } ?: "Starting…"
        Text(
            text = percentLabel,
            style = MaterialTheme.typography.labelMedium,
            color = LuminousMint,
            fontWeight = FontWeight.Bold
        )
        val sizeLabel = if (state.totalBytes > 0L) {
            "${formatFileSize(state.downloadedBytes)} / ${formatFileSize(state.totalBytes)}"
        } else {
            formatFileSize(state.downloadedBytes)
        }
        Text(
            text = sizeLabel,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        TextButton(
            onClick = onHide,
            colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary),
            modifier = Modifier.testTag("update_hide_button")
        ) {
            Text("Hide")
        }
    }
}

@Composable
private fun ReadyToInstallContent(
    state: AppUpdateState.ReadyToInstall,
    onInstallDownloaded: () -> Unit,
    onOpenInstallSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(ForestContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (state.needsInstallPermission) {
                    Icons.Rounded.Security
                } else {
                    Icons.Rounded.InstallMobile
                },
                contentDescription = null,
                tint = LuminousMint,
                modifier = Modifier.size(24.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (state.needsInstallPermission) {
                    "Allow App Updates"
                } else {
                    "Ready to Install"
                },
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Alt Player v${state.release.versionTag}",
                style = MaterialTheme.typography.bodySmall,
                color = LuminousMint
            )
        }
    }

    Text(
        text = if (state.needsInstallPermission) {
            "Enable \"Allow from this source\" in Android Settings so Alt Player can launch the downloaded APK installer."
        } else {
            "The update package is downloaded and ready. Tap below to launch the Android installer."
        },
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onDismiss,
            colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary),
            modifier = Modifier.testTag("update_later_button")
        ) {
            Text("Later")
        }

        Spacer(modifier = Modifier.width(8.dp))

        val actionLabel = if (state.needsInstallPermission) "Open Settings" else "Install Update"
        val actionTag = if (state.needsInstallPermission) "update_allow_install_button" else "update_install_button"
        Box(
            modifier = Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.horizontalGradient(listOf(TealEmeraldDeep, LuminousMint))
                )
                .clickable {
                    if (state.needsInstallPermission) {
                        onOpenInstallSettings()
                    } else {
                        onInstallDownloaded()
                    }
                }
                .padding(horizontal = 18.dp)
                .testTag(actionTag),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = ObsidianBlack,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun UpdateErrorContent(
    message: String,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(CoralError.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = CoralError,
                modifier = Modifier.size(24.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Update Check Issue",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Offline media playback continues normally",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
        }
    }

    Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onDismiss,
            colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary),
            modifier = Modifier.testTag("update_close_button")
        ) {
            Text("Close")
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.Transparent)
                .background(
                    Brush.horizontalGradient(listOf(TealEmeraldDeep, LuminousMint))
                )
                .clickable(onClick = onRetry)
                .padding(horizontal = 18.dp)
                .testTag("update_retry_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Retry",
                style = MaterialTheme.typography.labelLarge,
                color = ObsidianBlack,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
