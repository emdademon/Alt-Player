package com.example.ui.browser

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.DefaultOrientation
import com.example.data.ResumeBehavior
import com.example.ui.components.AltPlayerLogo
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldOffline
import com.example.ui.theme.OnCyanContainer
import com.example.ui.theme.OnVioletContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import com.example.ui.theme.VioletContainer

@Composable
fun SettingsScreen(
    uiState: LibraryUiState,
    onSelectResumeBehavior: (ResumeBehavior) -> Unit,
    onSelectDefaultOrientation: (DefaultOrientation) -> Unit,
    onToggleAutoLoadSrt: (Boolean) -> Unit,
    onToggleShowHiddenFolders: (Boolean) -> Unit,
    onOpenChangePin: () -> Unit,
    onClearPin: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = AmoledBlack,
        contentWindowInsets = WindowInsets.statusBars
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0A1220), AmoledBlack, AmoledBlack)
                    )
                )
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = TextPrimary
                    )
                }
                Text(
                    text = stringResource(R.string.settings_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Playback Preferences: Resume Behavior
                SettingsSectionHeader(
                    icon = Icons.Rounded.PlayCircleOutline,
                    title = "Default Resume Behavior"
                )
                Surface(
                    color = DeepNavySurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CardOutline)
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ResumeBehavior.entries.forEach { behavior ->
                            val selected = uiState.resumeBehavior == behavior
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectResumeBehavior(behavior) }
                                    .testTag("resume_behavior_${behavior.name.lowercase()}"),
                                color = if (selected) CyanContainer else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = behavior.label,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (selected) OnCyanContainer else TextPrimary
                                        )
                                        Text(
                                            text = behavior.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (selected) ElectricCyan else TextMuted
                                        )
                                    }
                                    if (selected) {
                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = ElectricCyan)
                                    }
                                }
                            }
                        }
                    }
                }

                // Default Screen Orientation
                SettingsSectionHeader(
                    icon = Icons.Rounded.ScreenRotation,
                    title = "Default Screen Orientation"
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DefaultOrientation.entries.forEach { orientation ->
                        val selected = uiState.defaultOrientation == orientation
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectDefaultOrientation(orientation) }
                                .testTag("default_orientation_${orientation.name.lowercase()}"),
                            color = if (selected) VioletContainer else DeepNavySurface,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, if (selected) ElectricCyan else CardOutline)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = orientation.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) OnVioletContainer else TextSecondary,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // Subtitles & Folders Toggles
                SettingsSectionHeader(
                    icon = Icons.Rounded.Subtitles,
                    title = "Subtitles & Folders"
                )
                Surface(
                    color = DeepNavySurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CardOutline)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Auto-load matching .srt subtitles",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Automatically attach same-named .srt files when available",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Switch(
                                checked = uiState.autoLoadSrt,
                                onCheckedChange = onToggleAutoLoadSrt,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = AmoledBlack,
                                    checkedTrackColor = ElectricCyan
                                ),
                                modifier = Modifier.testTag("switch_auto_load_srt")
                            )
                        }

                        HorizontalDivider(color = CardOutline)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Show Hidden Folders",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                val hiddenCount = uiState.hiddenBucketIds.size
                                Text(
                                    text = if (hiddenCount == 0) {
                                        "No folders are currently hidden"
                                    } else {
                                        "$hiddenCount hidden folder(s) on this device"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Switch(
                                checked = uiState.showHiddenFolders,
                                onCheckedChange = onToggleShowHiddenFolders,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = AmoledBlack,
                                    checkedTrackColor = ElectricCyan
                                ),
                                modifier = Modifier.testTag("switch_show_hidden_folders")
                            )
                        }
                    }
                }

                // Private Vault PIN Security
                SettingsSectionHeader(
                    icon = Icons.Rounded.Lock,
                    title = "Private Vault Security"
                )
                Surface(
                    color = DeepNavySurface,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, CardOutline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (uiState.hasPrivatePin) "4-Digit Vault PIN Active" else "Set Private Vault PIN",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Stored locally via SHA-256 hash",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }
                        Row {
                            TextButton(onClick = onOpenChangePin) {
                                Text(
                                    text = if (uiState.hasPrivatePin) "Change" else "Set PIN",
                                    color = ElectricCyan
                                )
                            }
                            if (uiState.hasPrivatePin && uiState.vaultVideos.isEmpty()) {
                                TextButton(onClick = onClearPin) {
                                    Text("Clear", color = TextSecondary)
                                }
                            }
                        }
                    }
                }

                // About Card
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("about_card"),
                    color = ElevatedNavy,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.28f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AltPlayerLogo(modifier = Modifier.size(44.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.VerifiedUser,
                                        contentDescription = null,
                                        tint = EmeraldOffline,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = stringResource(R.string.offline_privacy_badge),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldOffline
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = CardOutline)

                        Text(
                            text = stringResource(R.string.about_footer_text),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(18.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = ElectricCyan
        )
    }
}
