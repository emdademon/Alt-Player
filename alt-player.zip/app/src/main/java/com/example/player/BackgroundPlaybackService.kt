package com.example.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.example.MainActivity
import com.example.R

object ActivePlayerBridge {
    var player: Player? = null
    var title: String = "Alt Player"
    var onStopBackground: (() -> Unit)? = null
}

class BackgroundPlaybackService : Service() {

    private var mediaSession: MediaSession? = null
    private var playerListener: Player.Listener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        mediaSession = MediaSession(this, "AltPlayerBackgroundSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    ActivePlayerBridge.player?.play()
                    updateNotification()
                }

                override fun onPause() {
                    ActivePlayerBridge.player?.pause()
                    updateNotification()
                }

                override fun onStop() {
                    ActivePlayerBridge.player?.pause()
                    ActivePlayerBridge.onStopBackground?.invoke()
                    stopSelf()
                }
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_PLAY_PAUSE -> {
                val p = ActivePlayerBridge.player
                if (p != null) {
                    if (p.isPlaying) p.pause() else p.play()
                }
                updateNotification()
            }
            ACTION_STOP -> {
                ActivePlayerBridge.player?.pause()
                ActivePlayerBridge.onStopBackground?.invoke()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                attachListenerIfNeeded()
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun attachListenerIfNeeded() {
        val p = ActivePlayerBridge.player ?: return
        if (playerListener != null) return
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateNotification()
            }
        }
        p.addListener(listener)
        playerListener = listener
    }

    private fun updateNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val p = ActivePlayerBridge.player
        val isPlaying = p?.isPlaying == true

        mediaSession?.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or
                        PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_STOP
                )
                .setState(
                    if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    p?.currentPosition ?: 0L,
                    1f
                )
                .build()
        )

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BackgroundPlaybackService::class.java).apply {
                action = ACTION_TOGGLE_PLAY_PAUSE
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, BackgroundPlaybackService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val toggleLabel = if (isPlaying) "Pause" else "Play"

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle(ActivePlayerBridge.title)
            .setContentText("Background Audio • Alt Player")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppIntent)
            .setOngoing(isPlaying)
            .addAction(
                Notification.Action.Builder(toggleIcon, toggleLabel, toggleIntent).build()
            )
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "Stop",
                    stopIntent
                ).build()
            )
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(mediaSession?.sessionToken)
                    .setShowActionsInCompactView(0, 1)
            )
            .build()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Background Video Audio",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Controls for Alt Player background audio playback"
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    override fun onDestroy() {
        playerListener?.let { ActivePlayerBridge.player?.removeListener(it) }
        playerListener = null
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "altplayer_bg_audio"
        private const val NOTIFICATION_ID = 4102
        const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.player.ACTION_TOGGLE_PLAY_PAUSE"
        const val ACTION_STOP = "com.example.player.ACTION_STOP"

        fun start(context: Context) {
            val intent = Intent(context, BackgroundPlaybackService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BackgroundPlaybackService::class.java))
        }
    }
}
