package com.example.player

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.common.Tracks

enum class AspectMode(
    val label: String,
    val contentScale: ContentScale
) {
    FIT("Fit", ContentScale.Fit),
    STRETCH("Stretch", ContentScale.FillBounds),
    CROP("Crop", ContentScale.Crop);

    fun next(): AspectMode {
        val values = entries
        return values[(ordinal + 1) % values.size]
    }
}

enum class DecoderMode(val label: String, val fullName: String) {
    HW("HW", "Hardware Acceleration"),
    SW("SW", "Software Fallback")
}

enum class LoopMode(val label: String, val exoRepeatMode: Int) {
    OFF("Off", Player.REPEAT_MODE_OFF),
    REPEAT_ONE("Repeat One", Player.REPEAT_MODE_ONE),
    REPEAT_FOLDER("Repeat Folder", Player.REPEAT_MODE_ALL);

    fun next(): LoopMode = entries[(ordinal + 1) % entries.size]
}

enum class SleepTimerOption(val label: String, val minutes: Int?) {
    OFF("Off", null),
    MIN_15("15m", 15),
    MIN_30("30m", 30),
    MIN_45("45m", 45),
    MIN_60("60m", 60),
    END_OF_VIDEO("End of Video", -1)
}

enum class SubtitleFontSize(val label: String, val sp: TextUnit) {
    SMALL("Small", 14.sp),
    MEDIUM("Medium", 17.sp),
    LARGE("Large", 21.sp)
}

enum class SubtitleTextColor(val label: String, val color: Color) {
    WHITE("White", Color.White),
    YELLOW("Yellow", Color(0xFFFFD54F)),
    CYAN("Cyan", Color(0xFF00E5FF))
}

data class SubtitleStyleConfig(
    val fontSize: SubtitleFontSize = SubtitleFontSize.MEDIUM,
    val textColor: SubtitleTextColor = SubtitleTextColor.WHITE,
    val bgOpacity: Float = 0.72f
)

val PLAYBACK_SPEEDS = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)

data class AudioTrackOption(
    val id: String,
    val label: String,
    val detail: String,
    val isSelected: Boolean,
    val trackGroup: Tracks.Group,
    val trackIndex: Int
)

sealed interface SubtitleSelection {
    data object Off : SubtitleSelection
    data class Embedded(
        val id: String,
        val label: String,
        val language: String,
        val isSelected: Boolean,
        val trackGroup: Tracks.Group,
        val trackIndex: Int
    ) : SubtitleSelection

    data class External(
        val track: ExternalSubtitleTrack
    ) : SubtitleSelection
}

sealed interface GestureFeedback {
    data class Brightness(val percent: Int) : GestureFeedback
    data class Volume(val percent: Int, val isMuted: Boolean) : GestureFeedback
    data class HorizontalSeek(
        val targetMs: Long,
        val deltaMs: Long,
        val durationMs: Long
    ) : GestureFeedback

    data class DoubleTapSeek(
        val isForward: Boolean,
        val totalDeltaSeconds: Int
    ) : GestureFeedback

    data class PinchZoom(val percent: Int) : GestureFeedback
}

object PlayerMath {
    const val MIN_ZOOM_SCALE = 0.25f
    const val MAX_ZOOM_SCALE = 2.0f
    const val MIN_AUDIO_BOOST_PERCENT = 100
    const val MAX_AUDIO_BOOST_PERCENT = 200
    const val MIN_SUBTITLE_OFFSET_MS = -30_000L
    const val MAX_SUBTITLE_OFFSET_MS = 30_000L

    fun clampZoomScale(scale: Float): Float = scale.coerceIn(MIN_ZOOM_SCALE, MAX_ZOOM_SCALE)

    fun clampSubtitleOffsetMs(offsetMs: Long): Long =
        offsetMs.coerceIn(MIN_SUBTITLE_OFFSET_MS, MAX_SUBTITLE_OFFSET_MS)

    fun formatSubtitleOffset(offsetMs: Long): String {
        val sec = offsetMs / 1000.0
        return when {
            offsetMs > 0L -> String.format(java.util.Locale.US, "+%.1fs", sec)
            offsetMs < 0L -> String.format(java.util.Locale.US, "%.1fs", sec)
            else -> "0.0s"
        }
    }

    fun computeLoudnessGainMb(boostPercent: Int): Int {
        val clamped = boostPercent.coerceIn(MIN_AUDIO_BOOST_PERCENT, MAX_AUDIO_BOOST_PERCENT)
        return (clamped - 100) * 15
    }

    fun clampPipAspectRatio(width: Int, height: Int): Pair<Int, Int> {
        if (width <= 0 || height <= 0) return 16 to 9
        val ratio = width.toFloat() / height.toFloat()
        val clamped = ratio.coerceIn(0.45f, 2.2f)
        return (clamped * 1000f).toInt().coerceAtLeast(1) to 1000
    }
}

