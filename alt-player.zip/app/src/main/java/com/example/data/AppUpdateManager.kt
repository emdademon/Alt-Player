package com.example.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class GitHubReleaseInfo(
    val versionTag: String,
    val rawTagName: String,
    val releaseName: String,
    val releaseNotes: String,
    val apkDownloadUrl: String,
    val apkFileName: String,
    val apkSizeBytes: Long
)

sealed interface AppUpdateState {
    data object Idle : AppUpdateState
    data object Checking : AppUpdateState
    data class UpToDate(val currentVersion: String) : AppUpdateState
    data class UpdateAvailable(
        val release: GitHubReleaseInfo,
        val currentVersion: String
    ) : AppUpdateState

    data class Downloading(
        val release: GitHubReleaseInfo,
        val currentVersion: String,
        val progressFraction: Float?,
        val downloadedBytes: Long,
        val totalBytes: Long
    ) : AppUpdateState

    data class ReadyToInstall(
        val release: GitHubReleaseInfo,
        val apkFilePath: String,
        val needsInstallPermission: Boolean
    ) : AppUpdateState

    data class Error(val message: String) : AppUpdateState
}

sealed interface ReleaseFetchOutcome {
    data class Success(val release: GitHubReleaseInfo) : ReleaseFetchOutcome
    data class Failure(val reason: String) : ReleaseFetchOutcome
}

data class DownloadSnapshot(
    val status: Int,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val localUri: String?
)

enum class ApkInstallLaunchResult {
    LAUNCHED,
    NEEDS_PERMISSION,
    FILE_MISSING,
    FAILED
}

object AppUpdateManager {

    const val GITHUB_LATEST_RELEASE_URL =
        "https://api.github.com/repos/emdademon/Alt-Player/releases/latest"

    fun getInstalledVersionName(context: Context): String {
        return runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
            normalizeVersionTag(info.versionName.orEmpty()).ifBlank { "1.0" }
        }.getOrDefault("1.0")
    }

    fun isNetworkConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun fetchLatestRelease(
        endpointUrl: String = GITHUB_LATEST_RELEASE_URL
    ): ReleaseFetchOutcome = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(endpointUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 8_000
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "AltPlayer-Android")
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                return@withContext ReleaseFetchOutcome.Failure("GitHub returned HTTP $code")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val parsed = parseLatestReleaseJson(body)
                ?: return@withContext ReleaseFetchOutcome.Failure("No installable APK found in latest release")
            ReleaseFetchOutcome.Success(parsed)
        } catch (t: Throwable) {
            ReleaseFetchOutcome.Failure(t.message ?: "Network error while checking for updates")
        } finally {
            connection?.disconnect()
        }
    }

    fun parseLatestReleaseJson(jsonText: String): GitHubReleaseInfo? {
        return runCatching {
            val root = JSONObject(jsonText)
            if (root.optBoolean("draft", false)) return null

            val rawTag = root.optString("tag_name", "").trim()
            val normalizedTag = normalizeVersionTag(rawTag)
            if (normalizedTag.isBlank()) return null

            val releaseName = root.optString("name", "").trim()
                .ifBlank { "Alt Player v$normalizedTag" }
            val releaseNotes = root.optString("body", "").trim()
                .ifBlank { "Performance improvements and offline playback refinements." }

            val assets = root.optJSONArray("assets") ?: return null
            if (assets.length() == 0) return null

            var selectedAsset: JSONObject? = null
            for (i in 0 until assets.length()) {
                val candidate = assets.optJSONObject(i) ?: continue
                val url = candidate.optString("browser_download_url", "")
                val name = candidate.optString("name", "")
                if (url.endsWith(".apk", ignoreCase = true) || name.endsWith(".apk", ignoreCase = true)) {
                    selectedAsset = candidate
                    break
                }
            }
            if (selectedAsset == null) {
                selectedAsset = assets.optJSONObject(0)
            }
            val asset = selectedAsset ?: return null
            val downloadUrl = asset.optString("browser_download_url", "").trim()
            if (downloadUrl.isBlank()) return null

            val fileName = asset.optString("name", "")
                .trim()
                .ifBlank { "AltPlayer-$normalizedTag.apk" }
            val safeFileName = if (fileName.endsWith(".apk", ignoreCase = true)) {
                fileName
            } else {
                "$fileName.apk"
            }

            GitHubReleaseInfo(
                versionTag = normalizedTag,
                rawTagName = rawTag,
                releaseName = releaseName,
                releaseNotes = releaseNotes,
                apkDownloadUrl = downloadUrl,
                apkFileName = safeFileName.replace(Regex("[^a-zA-Z0-9._-]"), "_"),
                apkSizeBytes = asset.optLong("size", 0L).coerceAtLeast(0L)
            )
        }.getOrNull()
    }

    fun normalizeVersionTag(raw: String): String {
        val trimmed = raw.trim()
        return trimmed.dropWhile { it == 'v' || it == 'V' }.trim()
    }

    fun isNewerVersion(latestTag: String, currentVersion: String): Boolean {
        val latestClean = normalizeVersionTag(latestTag)
        val currentClean = normalizeVersionTag(currentVersion)
        if (latestClean.isBlank() || currentClean.isBlank()) return false
        if (latestClean.equals(currentClean, ignoreCase = true)) return false

        val latestBase = latestClean.substringBefore('-').substringBefore('+')
        val currentBase = currentClean.substringBefore('-').substringBefore('+')

        val latestParts = latestBase.split('.').map { part ->
            part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
        }
        val currentParts = currentBase.split('.').map { part ->
            part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
        }

        val maxLen = maxOf(latestParts.size, currentParts.size)
        for (i in 0 until maxLen) {
            val l = latestParts.getOrElse(i) { 0 }
            val c = currentParts.getOrElse(i) { 0 }
            if (l != c) return l > c
        }

        val latestHasPrerelease = latestClean.contains('-')
        val currentHasPrerelease = currentClean.contains('-')
        return !latestHasPrerelease && currentHasPrerelease
    }

    fun resolveApkDestinationFile(context: Context, release: GitHubReleaseInfo): File {
        val downloadDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "Download").apply { mkdirs() }
        if (!downloadDir.exists()) downloadDir.mkdirs()
        return File(downloadDir, release.apkFileName)
    }

    fun enqueueApkDownload(context: Context, release: GitHubReleaseInfo): Pair<Long, File>? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
            ?: return null
        val destFile = resolveApkDestinationFile(context, release)
        if (destFile.exists()) {
            runCatching { destFile.delete() }
        }

        val request = DownloadManager.Request(Uri.parse(release.apkDownloadUrl)).apply {
            setTitle("Alt Player v${release.versionTag}")
            setDescription("Downloading app update...")
            setMimeType("application/vnd.android.package-archive")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
            setDestinationInExternalFilesDir(
                context,
                Environment.DIRECTORY_DOWNLOADS,
                release.apkFileName
            )
        }

        val id = runCatching { dm.enqueue(request) }.getOrNull() ?: return null
        return id to destFile
    }

    fun queryDownloadSnapshot(context: Context, downloadId: Long): DownloadSnapshot? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
            ?: return null
        val query = DownloadManager.Query().setFilterById(downloadId)
        dm.query(query)?.use { cursor ->
            if (!cursor.moveToFirst()) return null
            val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val downloadedIdx = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val totalIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val uriIdx = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

            return DownloadSnapshot(
                status = if (statusIdx >= 0) cursor.getInt(statusIdx) else DownloadManager.STATUS_PENDING,
                downloadedBytes = if (downloadedIdx >= 0) cursor.getLong(downloadedIdx).coerceAtLeast(0L) else 0L,
                totalBytes = if (totalIdx >= 0) cursor.getLong(totalIdx).coerceAtLeast(-1L) else -1L,
                localUri = if (uriIdx >= 0) cursor.getString(uriIdx) else null
            )
        }
        return null
    }

    fun canInstallPackages(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    fun buildManageUnknownSourcesIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        return Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun launchApkInstaller(context: Context, apkFile: File): ApkInstallLaunchResult {
        if (!apkFile.exists() || apkFile.length() <= 0L) {
            return ApkInstallLaunchResult.FILE_MISSING
        }
        if (!canInstallPackages(context)) {
            return ApkInstallLaunchResult.NEEDS_PERMISSION
        }
        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
            ApkInstallLaunchResult.LAUNCHED
        } catch (_: Throwable) {
            ApkInstallLaunchResult.FAILED
        }
    }
}
