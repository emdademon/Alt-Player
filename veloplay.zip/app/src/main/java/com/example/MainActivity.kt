package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.MediaAccessState
import com.example.ui.browser.FolderDetailScreen
import com.example.ui.browser.LibraryScreen
import com.example.ui.browser.LibraryViewModel
import com.example.ui.player.PlayerScreen
import com.example.ui.theme.VeloPlayTheme

object Routes {
    const val LIBRARY = "library"
    const val FOLDER_DETAIL = "folder/{bucketId}"
    const val PLAYER = "player"

    fun folderDetail(bucketId: String): String = "folder/${Uri.encode(bucketId)}"
}

class MainActivity : ComponentActivity() {

    private val libraryViewModel: LibraryViewModel by viewModels()
    private var pendingViewUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIncomingIntent(intent)

        setContent {
            VeloPlayTheme {
                VeloPlayApp(
                    libraryViewModel = libraryViewModel,
                    pendingViewUri = pendingViewUri,
                    onConsumePendingUri = { pendingViewUri = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                pendingViewUri = uri
            }
        }
    }
}

@Composable
fun VeloPlayApp(
    libraryViewModel: LibraryViewModel,
    pendingViewUri: Uri?,
    onConsumePendingUri: () -> Unit
) {
    val navController = rememberNavController()
    val uiState by libraryViewModel.uiState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    // Re-check media access state when returning from Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && uiState.accessState == MediaAccessState.DENIED) {
                libraryViewModel.refreshPermissionAndScan()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(pendingViewUri) {
        val uri = pendingViewUri ?: return@LaunchedEffect
        onConsumePendingUri()
        libraryViewModel.openExternalVideo(uri) {
            navController.navigate(Routes.PLAYER) {
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.LIBRARY,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() }
    ) {
        composable(Routes.LIBRARY) {
            LibraryScreen(
                uiState = uiState,
                onSearchQueryChange = libraryViewModel::onSearchQueryChange,
                onSelectTab = libraryViewModel::onSelectTab,
                onSelectSort = libraryViewModel::onSelectSort,
                onRefreshScan = libraryViewModel::refreshPermissionAndScan,
                onOpenFolder = { folder ->
                    navController.navigate(Routes.folderDetail(folder.bucketId))
                },
                onPlayVideo = { video, playlist ->
                    libraryViewModel.startPlayback(video, playlist)
                    navController.navigate(Routes.PLAYER)
                },
                onOpenExternalUri = { uri ->
                    libraryViewModel.openExternalVideo(uri) {
                        navController.navigate(Routes.PLAYER)
                    }
                }
            )
        }

        composable(
            route = Routes.FOLDER_DETAIL,
            arguments = listOf(navArgument("bucketId") { type = NavType.StringType })
        ) { backStackEntry ->
            val rawBucketId = backStackEntry.arguments?.getString("bucketId").orEmpty()
            val bucketId = Uri.decode(rawBucketId)
            val folder = libraryViewModel.getFolderById(bucketId)

            FolderDetailScreen(
                folder = folder,
                searchQuery = uiState.searchQuery,
                sortOption = uiState.sortOption,
                sortOrder = uiState.sortOrder,
                positionsByUri = uiState.positionsByUri,
                watchedUris = uiState.watchedUris,
                onSearchQueryChange = libraryViewModel::onSearchQueryChange,
                onSelectSort = libraryViewModel::onSelectSort,
                onBack = { navController.popBackStack() },
                onPlayVideo = { video, playlist ->
                    libraryViewModel.startPlayback(video, playlist)
                    navController.navigate(Routes.PLAYER)
                }
            )
        }

        composable(Routes.PLAYER) {
            PlayerScreen(
                playlist = uiState.activePlaylist,
                initialIndex = uiState.activeVideoIndex,
                getResumePositionMs = libraryViewModel::getResumePositionMs,
                onSaveProgress = libraryViewModel::savePlaybackProgress,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
