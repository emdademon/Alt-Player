package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.veloPlayDataStore: DataStore<Preferences> by preferencesDataStore(name = "veloplay_prefs")

data class PlaybackPreferencesSnapshot(
    val sortOption: SortOption = SortOption.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val lastPlayedUri: String? = null,
    val positionsByUri: Map<String, Long> = emptyMap(),
    val watchedUris: Set<String> = emptySet()
)

class PlaybackPreferencesRepository(private val context: Context) {

    private object Keys {
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val LAST_PLAYED_URI = stringPreferencesKey("last_played_uri")
    }

    val preferencesFlow: Flow<PlaybackPreferencesSnapshot> = context.veloPlayDataStore.data.map { prefs ->
        val sortOption = prefs[Keys.SORT_OPTION]?.let {
            runCatching { SortOption.valueOf(it) }.getOrNull()
        } ?: SortOption.DATE
        val sortOrder = prefs[Keys.SORT_ORDER]?.let {
            runCatching { SortOrder.valueOf(it) }.getOrNull()
        } ?: SortOrder.DESCENDING
        val lastPlayedUri = prefs[Keys.LAST_PLAYED_URI]

        val positions = mutableMapOf<String, Long>()
        val watched = mutableSetOf<String>()
        prefs.asMap().forEach { (key, value) ->
            val keyName = key.name
            if (keyName.startsWith(POS_PREFIX) && value is Long) {
                val uriKey = keyName.removePrefix(POS_PREFIX)
                positions[uriKey] = value
                watched.add(uriKey)
            }
        }

        PlaybackPreferencesSnapshot(
            sortOption = sortOption,
            sortOrder = sortOrder,
            lastPlayedUri = lastPlayedUri,
            positionsByUri = positions,
            watchedUris = watched
        )
    }

    suspend fun saveSortPreference(option: SortOption, order: SortOrder) {
        context.veloPlayDataStore.edit { prefs ->
            prefs[Keys.SORT_OPTION] = option.name
            prefs[Keys.SORT_ORDER] = order.name
        }
    }

    suspend fun savePlaybackProgress(uriString: String, positionMs: Long, durationMs: Long) {
        val safeUriKey = uriKey(uriString)
        context.veloPlayDataStore.edit { prefs ->
            prefs[Keys.LAST_PLAYED_URI] = uriString
            val nearEnd = durationMs > 0 && positionMs >= (durationMs - 3_000L).coerceAtLeast(0L)
            prefs[longPreferencesKey(POS_PREFIX + safeUriKey)] = if (nearEnd) 0L else positionMs.coerceAtLeast(0L)
        }
    }

    companion object {
        private const val POS_PREFIX = "pos_"
        fun uriKey(uriString: String): String = uriString.hashCode().toUInt().toString(16)
    }
}
