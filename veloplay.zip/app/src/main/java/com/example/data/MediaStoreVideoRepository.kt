package com.example.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreVideoRepository(private val context: Context) {

    fun checkMediaAccessState(): MediaAccessState {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> {
                val fullGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED
                val partialGranted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                ) == PackageManager.PERMISSION_GRANTED
                when {
                    fullGranted -> MediaAccessState.GRANTED_ALL
                    partialGranted -> MediaAccessState.GRANTED_PARTIAL
                    else -> MediaAccessState.DENIED
                }
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_VIDEO
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) MediaAccessState.GRANTED_ALL else MediaAccessState.DENIED
            }
            else -> {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) MediaAccessState.GRANTED_ALL else MediaAccessState.DENIED
            }
        }
    }

    suspend fun scanAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projectionList = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            projectionList.add(MediaStore.Video.Media.RELATIVE_PATH)
        } else {
            @Suppress("DEPRECATION")
            projectionList.add(MediaStore.Video.Media.DATA)
        }

        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        runCatching {
            context.contentResolver.query(
                collection,
                projectionList.toTypedArray(),
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val bucketIdCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
                val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val pathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else {
                    @Suppress("DEPRECATION")
                    cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol).orEmpty()
                    val mimeType = cursor.getString(mimeCol).orEmpty().lowercase()
                    val ext = displayName.substringAfterLast('.', "").lowercase()

                    if (!isSupportedVideoFormat(ext, mimeType)) continue

                    val sizeBytes = cursor.getLong(sizeCol)
                    if (sizeBytes <= 0L) continue

                    val rawTitle = cursor.getString(titleCol).orEmpty()
                    val cleanTitle = rawTitle.ifBlank {
                        displayName.substringBeforeLast('.', displayName)
                    }

                    val bucketId = cursor.getString(bucketIdCol).orEmpty().ifBlank { "root" }
                    val rawPath = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""
                    val folderPath = normalizeFolderPath(rawPath)
                    val folderName = cursor.getString(bucketNameCol).orEmpty().ifBlank {
                        folderPath.trimEnd('/').substringAfterLast('/', "Internal Storage")
                    }

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    videos.add(
                        VideoItem(
                            id = id,
                            uri = contentUri,
                            title = cleanTitle,
                            displayName = displayName,
                            bucketId = bucketId,
                            folderName = folderName,
                            folderPath = folderPath.ifBlank { folderName },
                            durationMs = cursor.getLong(durationCol).coerceAtLeast(0L),
                            sizeBytes = sizeBytes,
                            width = cursor.getInt(widthCol).coerceAtLeast(0),
                            height = cursor.getInt(heightCol).coerceAtLeast(0),
                            dateModifiedSec = cursor.getLong(dateCol).coerceAtLeast(0L),
                            mimeType = mimeType,
                            extension = ext.uppercase().ifBlank { mimeToExt(mimeType) }
                        )
                    )
                }
            }
        }
        videos
    }

    suspend fun resolveDocumentVideo(uri: Uri): VideoItem = withContext(Dispatchers.IO) {
        var displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "Local Video"
        var sizeBytes = 0L

        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) {
                        cursor.getString(nameIdx)?.takeIf { it.isNotBlank() }?.let { displayName = it }
                    }
                    if (sizeIdx >= 0) {
                        sizeBytes = cursor.getLong(sizeIdx).coerceAtLeast(0L)
                    }
                }
            }
        }

        var durationMs = 0L
        var width = 0
        var height = 0
        val retriever = MediaMetadataRetriever()
        runCatching {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
        }
        runCatching { retriever.release() }

        val ext = displayName.substringAfterLast('.', "VIDEO").uppercase()
        val cleanTitle = displayName.substringBeforeLast('.', displayName)
        val mime = context.contentResolver.getType(uri).orEmpty()

        VideoItem(
            id = uri.toString().hashCode().toLong(),
            uri = uri,
            title = cleanTitle,
            displayName = displayName,
            bucketId = "external_pick",
            folderName = "Opened Files",
            folderPath = "Device Storage",
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height,
            dateModifiedSec = System.currentTimeMillis() / 1000L,
            mimeType = mime,
            extension = ext,
            isExternalPick = true
        )
    }

    fun groupVideosByFolder(videos: List<VideoItem>): List<VideoFolder> {
        return videos.groupBy { it.bucketId }
            .map { (bucketId, folderVideos) ->
                val sample = folderVideos.first()
                VideoFolder(
                    bucketId = bucketId,
                    name = sample.folderName,
                    path = sample.folderPath,
                    videos = folderVideos
                )
            }
    }

    private fun normalizeFolderPath(rawPath: String): String {
        if (rawPath.isBlank()) return ""
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            rawPath.trimEnd('/')
        } else {
            File(rawPath).parent?.removePrefix("/storage/emulated/0/") ?: ""
        }
    }

    companion object {
        private val SUPPORTED_EXTENSIONS = setOf("mp4", "mkv", "avi", "webm", "m4v", "mov")
        private val SUPPORTED_MIMES = setOf(
            "video/mp4",
            "video/x-matroska",
            "video/matroska",
            "video/avi",
            "video/x-msvideo",
            "video/msvideo",
            "video/webm",
            "video/quicktime"
        )

        fun isSupportedVideoFormat(extension: String, mimeType: String): Boolean {
            val ext = extension.lowercase()
            val mime = mimeType.lowercase()
            return ext in SUPPORTED_EXTENSIONS ||
                mime in SUPPORTED_MIMES ||
                (ext.isBlank() && mime.startsWith("video/"))
        }

        private fun mimeToExt(mimeType: String): String {
            return when {
                mimeType.contains("mp4") -> "MP4"
                mimeType.contains("matroska") -> "MKV"
                mimeType.contains("avi") -> "AVI"
                mimeType.contains("webm") -> "WEBM"
                else -> "VIDEO"
            }
        }
    }
}
