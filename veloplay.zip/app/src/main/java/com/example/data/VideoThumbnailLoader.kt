package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VideoThumbnailLoader {
    private val memoryCache = LruCache<String, ImageBitmap>(72)

    fun getCached(uri: Uri): ImageBitmap? = memoryCache.get(uri.toString())

    suspend fun loadThumbnail(context: Context, video: VideoItem): ImageBitmap? {
        val key = video.uri.toString()
        memoryCache.get(key)?.let { return it }

        val bitmap: Bitmap? = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !video.isExternalPick) {
                    context.contentResolver.loadThumbnail(video.uri, Size(480, 270), null)
                } else {
                    loadWithRetriever(context, video.uri) ?: loadLegacyMediaStoreThumb(context, video.id)
                }
            } catch (_: Throwable) {
                runCatching { loadWithRetriever(context, video.uri) }.getOrNull()
            }
        }

        return bitmap?.asImageBitmap()?.also { imageBitmap ->
            memoryCache.put(key, imageBitmap)
        }
    }

    private fun loadWithRetriever(context: Context, uri: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 0L
            val targetUs = if (durationMs > 4_000L) 2_000_000L else (durationMs * 250L)
            retriever.getFrameAtTime(targetUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(-1)
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    @Suppress("DEPRECATION")
    private fun loadLegacyMediaStoreThumb(context: Context, videoId: Long): Bitmap? {
        if (videoId <= 0L) return null
        return runCatching {
            MediaStore.Video.Thumbnails.getThumbnail(
                context.contentResolver,
                videoId,
                MediaStore.Video.Thumbnails.MINI_KIND,
                null
            )
        }.getOrNull()
    }
}
