package com.example.player

import androidx.compose.ui.layout.ContentScale
import androidx.media3.common.Tracks

enum class AspectMode(
    val label: String,
    val contentScale: ContentScale
) {
    FIT("Fit", ContentScale.Fit),
    STRETCH("Stretch", ContentScale.FillBounds),
    CROP("Crop", ContentScale.Crop);

    fun next(): AspectMode {
        val values = entries
        return values[(ordinal + 1) % values.size]
    }
}

val PLAYBACK_SPEEDS = listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f)

data class AudioTrackOption(
    val id: String,
    val label: String,
    val detail: String,
    val isSelected: Boolean,
    val trackGroup: Tracks.Group,
    val trackIndex: Int
)

sealed interface SubtitleSelection {
    data object Off : SubtitleSelection
    data class Embedded(
        val id: String,
        val label: String,
        val language: String,
        val isSelected: Boolean,
        val trackGroup: Tracks.Group,
        val trackIndex: Int
    ) : SubtitleSelection

    data class External(
        val track: ExternalSubtitleTrack
    ) : SubtitleSelection
}

sealed interface GestureFeedback {
    data class Brightness(val percent: Int) : GestureFeedback
    data class Volume(val percent: Int, val isMuted: Boolean) : GestureFeedback
    data class HorizontalSeek(
        val targetMs: Long,
        val deltaMs: Long,
        val durationMs: Long
    ) : GestureFeedback

    data class DoubleTapSeek(
        val isForward: Boolean,
        val totalDeltaSeconds: Int
    ) : GestureFeedback
}
