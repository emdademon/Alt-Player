package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AMOLED Cinema Dark Palette
val AmoledBlack = Color(0xFF05070B)
val DeepNavySurface = Color(0xFF0B101B)
val ElevatedNavy = Color(0xFF121927)
val SurfaceHighlight = Color(0xFF1A2336)
val CardOutline = Color(0xFF232E45)

// Vibrant Accents
val ElectricCyan = Color(0xFF00E5FF)
val CyanMuted = Color(0xFF00B8D4)
val CyanContainer = Color(0xFF063240)
val OnCyanContainer = Color(0xFFB2F5FF)

val VioletAccent = Color(0xFF7C4DFF)
val VioletContainer = Color(0xFF23174B)
val OnVioletContainer = Color(0xFFE0D4FF)

val AmberWarm = Color(0xFFFFB300)
val EmeraldOffline = Color(0xFF10B981)
val CoralError = Color(0xFFFF5252)

// Typography Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
