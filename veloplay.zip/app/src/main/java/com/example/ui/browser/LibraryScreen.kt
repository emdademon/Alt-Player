package com.example.ui.browser

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LibraryTab
import com.example.data.MediaAccessState
import com.example.data.PlaybackPreferencesRepository
import com.example.data.SortOption
import com.example.data.SortOrder
import com.example.data.VideoFolder
import com.example.data.VideoItem
import com.example.ui.components.ContinueWatchingBanner
import com.example.ui.components.FolderCard
import com.example.ui.components.PrivacyShieldSheet
import com.example.ui.components.SortOptionsSheet
import com.example.ui.components.VideoCard
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.CardOutline
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldOffline
import com.example.ui.theme.OnCyanContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent

@Composable
fun LibraryScreen(
    uiState: LibraryUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectTab: (LibraryTab) -> Unit,
    onSelectSort: (SortOption, SortOrder) -> Unit,
    onRefreshScan: () -> Unit,
    onOpenFolder: (VideoFolder) -> Unit,
    onPlayVideo: (VideoItem, List<VideoItem>) -> Unit,
    onOpenExternalUri: (android.net.Uri) -> Unit
) {
    var showSortSheet by remember { mutableStateOf(false) }
    var showPrivacySheet by remember { mutableStateOf(false) }

    val permissionsToRequest = remember {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO
            )
            else -> arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefreshScan()
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onOpenExternalUri(uri)
        }
    }

    Scaffold(
        containerColor = AmoledBlack,
        contentWindowInsets = WindowInsets.statusBars
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0A1220),
                            AmoledBlack,
                            AmoledBlack
                        )
                    )
                )
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                LibraryHeader(
                    onPrivacyClick = { showPrivacySheet = true },
                    onOpenFileClick = { openDocumentLauncher.launch(arrayOf("video/*")) },
                    onRescanClick = onRefreshScan,
                    onSortClick = { showSortSheet = true }
                )

                // Search Bar
                SearchCapsule(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )

                // Segmented Tab Switcher (Folders / All Videos)
                if (uiState.accessState == MediaAccessState.GRANTED_ALL ||
                    uiState.accessState == MediaAccessState.GRANTED_PARTIAL
                ) {
                    LibraryTabRow(
                        activeTab = uiState.activeTab,
                        folderCount = uiState.filteredFolders.size,
                        videoCount = uiState.filteredVideos.size,
                        onSelectTab = onSelectTab,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                // Partial access callout on Android 14+
                AnimatedVisibility(visible = uiState.accessState == MediaAccessState.GRANTED_PARTIAL) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        color = CyanContainer.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.partial_access_banner),
                                style = MaterialTheme.typography.bodySmall,
                                color = OnCyanContainer,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = stringResource(R.string.grant_full_access),
                                style = MaterialTheme.typography.labelLarge,
                                color = ElectricCyan,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { permissionLauncher.launch(permissionsToRequest) }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("grant_full_access_button")
                            )
                        }
                    }
                }

                // Body Content
                when {
                    uiState.isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ElectricCyan)
                        }
                    }

                    uiState.accessState == MediaAccessState.DENIED ||
                        uiState.accessState == MediaAccessState.UNKNOWN -> {
                        PermissionRequestView(
                            onGrantPermission = { permissionLauncher.launch(permissionsToRequest) },
                            onPickFile = { openDocumentLauncher.launch(arrayOf("video/*")) }
                        )
                    }

                    uiState.allVideos.isEmpty() -> {
                        EmptyLibraryView(
                            isSearchEmpty = false,
                            onAction = { openDocumentLauncher.launch(arrayOf("video/*")) },
                            onRescan = onRefreshScan
                        )
                    }

                    (uiState.activeTab == LibraryTab.FOLDERS && uiState.filteredFolders.isEmpty()) ||
                        (uiState.activeTab == LibraryTab.ALL_VIDEOS && uiState.filteredVideos.isEmpty()) -> {
                        EmptyLibraryView(
                            isSearchEmpty = true,
                            onAction = { onSearchQueryChange("") },
                            onRescan = onRefreshScan
                        )
                    }

                    else -> {
                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val columns = if (maxWidth >= 640.dp) 2 else 1
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(columns),
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = 6.dp,
                                    bottom = 28.dp
                                ),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                val continueVideo = uiState.continueWatchingVideo
                                if (continueVideo != null && uiState.searchQuery.isBlank()) {
                                    item(span = { GridItemSpan(columns) }) {
                                        ContinueWatchingBanner(
                                            video = continueVideo,
                                            positionMs = uiState.continueWatchingPositionMs,
                                            onResumeClick = {
                                                val folderVideos = uiState.folders
                                                    .find { it.bucketId == continueVideo.bucketId }
                                                    ?.videos ?: uiState.filteredVideos
                                                onPlayVideo(continueVideo, folderVideos)
                                            },
                                            modifier = Modifier.padding(bottom = 4.dp)
                                        )
                                    }
                                }

                                if (uiState.activeTab == LibraryTab.FOLDERS) {
                                    items(
                                        items = uiState.filteredFolders,
                                        key = { it.bucketId }
                                    ) { folder ->
                                        val hasUnwatched = folder.videos.any { vid ->
                                            val key = PlaybackPreferencesRepository.uriKey(vid.uri.toString())
                                            key !in uiState.watchedUris
                                        }
                                        FolderCard(
                                            folder = folder,
                                            hasUnwatchedVideos = hasUnwatched,
                                            onClick = { onOpenFolder(folder) }
                                        )
                                    }
                                } else {
                                    items(
                                        items = uiState.filteredVideos,
                                        key = { it.id }
                                    ) { video ->
                                        val key = PlaybackPreferencesRepository.uriKey(video.uri.toString())
                                        val resumeMs = uiState.positionsByUri[key] ?: 0L
                                        val isWatched = key in uiState.watchedUris
                                        VideoCard(
                                            video = video,
                                            resumePositionMs = resumeMs,
                                            isWatched = isWatched,
                                            onClick = { onPlayVideo(video, uiState.filteredVideos) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortSheet) {
        SortOptionsSheet(
            currentOption = uiState.sortOption,
            currentOrder = uiState.sortOrder,
            onSelectSort = onSelectSort,
            onDismiss = { showSortSheet = false }
        )
    }

    if (showPrivacySheet) {
        PrivacyShieldSheet(onDismiss = { showPrivacySheet = false })
    }
}

@Composable
private fun LibraryHeader(
    onPrivacyClick: () -> Unit,
    onOpenFileClick: () -> Unit,
    onRescanClick: () -> Unit,
    onSortClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Brand badge
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(ElectricCyan, VioletAccent)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.PlayCircle,
                contentDescription = null,
                tint = AmoledBlack,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                maxLines = 1
            )
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(onClick = onPrivacyClick)
                    .testTag("offline_privacy_badge"),
                color = EmeraldOffline.copy(alpha = 0.14f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = EmeraldOffline,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = stringResource(R.string.offline_privacy_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldOffline,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        IconButton(
            onClick = onOpenFileClick,
            modifier = Modifier.testTag("open_file_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.FileOpen,
                contentDescription = stringResource(R.string.open_video_file),
                tint = TextPrimary
            )
        }

        IconButton(
            onClick = onRescanClick,
            modifier = Modifier.testTag("rescan_button")
        ) {
            Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.refresh_library),
                tint = TextSecondary
            )
        }

        IconButton(
            onClick = onSortClick,
            modifier = Modifier.testTag("sort_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.Sort,
                contentDescription = stringResource(R.string.sort_by),
                tint = ElectricCyan
            )
        }
    }
}

@Composable
fun SearchCapsule(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DeepNavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_videos_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    cursorBrush = SolidColor(ElectricCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_videos_input")
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.clear_search),
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .clickable { onQueryChange("") }
                        .testTag("clear_search_button")
                )
            }
        }
    }
}

@Composable
private fun LibraryTabRow(
    activeTab: LibraryTab,
    folderCount: Int,
    videoCount: Int,
    onSelectTab: (LibraryTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DeepNavySurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CardOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val foldersSelected = activeTab == LibraryTab.FOLDERS
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectTab(LibraryTab.FOLDERS) }
                    .testTag("tab_folders"),
                color = if (foldersSelected) ElevatedNavy else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Folder,
                        contentDescription = null,
                        tint = if (foldersSelected) ElectricCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${stringResource(R.string.tab_folders)} ($folderCount)",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (foldersSelected) TextPrimary else TextSecondary
                    )
                }
            }

            val allSelected = activeTab == LibraryTab.ALL_VIDEOS
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectTab(LibraryTab.ALL_VIDEOS) }
                    .testTag("tab_all_videos"),
                color = if (allSelected) ElevatedNavy else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VideoLibrary,
                        contentDescription = null,
                        tint = if (allSelected) ElectricCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${stringResource(R.string.tab_all_videos)} ($videoCount)",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (allSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionRequestView(
    onGrantPermission: () -> Unit,
    onPickFile: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_cinema),
                contentDescription = stringResource(R.string.permission_title),
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )

            Text(
                text = stringResource(R.string.permission_title),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = stringResource(R.string.permission_description),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onGrantPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("grant_permission_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricCyan,
                    contentColor = AmoledBlack
                )
            ) {
                Text(
                    text = stringResource(R.string.grant_permission),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onPickFile,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("pick_video_directly_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CardOutline)
            ) {
                Icon(
                    imageVector = Icons.Rounded.FileOpen,
                    contentDescription = null,
                    tint = ElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.pick_video_directly),
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
            }
        }
    }
}

@Composable
private fun EmptyLibraryView(
    isSearchEmpty: Boolean,
    onAction: () -> Unit,
    onRescan: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 380.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_cinema),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth(0.65f)
                    .clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                text = stringResource(
                    if (isSearchEmpty) R.string.empty_search_title else R.string.empty_library_title
                ),
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(
                    if (isSearchEmpty) R.string.empty_search_subtitle else R.string.empty_library_subtitle
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAction,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = AmoledBlack
                    ),
                    modifier = Modifier.testTag("empty_primary_action")
                ) {
                    Text(
                        text = stringResource(
                            if (isSearchEmpty) R.string.clear_search else R.string.pick_video_directly
                        ),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                if (!isSearchEmpty) {
                    OutlinedButton(
                        onClick = onRescan,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CardOutline)
                    ) {
                        Text(
                            text = stringResource(R.string.refresh_library),
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}
