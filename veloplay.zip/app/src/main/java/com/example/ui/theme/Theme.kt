package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val VeloDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = AmoledBlack,
    primaryContainer = CyanContainer,
    onPrimaryContainer = OnCyanContainer,
    secondary = VioletAccent,
    onSecondary = TextPrimary,
    secondaryContainer = VioletContainer,
    onSecondaryContainer = OnVioletContainer,
    tertiary = AmberWarm,
    onTertiary = AmoledBlack,
    background = AmoledBlack,
    onBackground = TextPrimary,
    surface = DeepNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedNavy,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = AmoledBlack,
    surfaceContainerLow = DeepNavySurface,
    surfaceContainer = ElevatedNavy,
    surfaceContainerHigh = SurfaceHighlight,
    surfaceContainerHighest = ColorTokens.SurfaceHighest,
    outline = CardOutline,
    outlineVariant = ColorTokens.SubtleDivider,
    error = CoralError,
    onError = TextPrimary
)

private object ColorTokens {
    val SurfaceHighest = androidx.compose.ui.graphics.Color(0xFF212B42)
    val SubtleDivider = androidx.compose.ui.graphics.Color(0xFF192234)
}

val VeloShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VeloPlayTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VeloDarkColorScheme,
        typography = VeloTypography,
        shapes = VeloShapes,
        content = content
    )
}
