package com.example.ui.browser

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LibraryTab
import com.example.data.MediaAccessState
import com.example.data.MediaStoreVideoRepository
import com.example.data.PlaybackPreferencesRepository
import com.example.data.PlaybackPreferencesSnapshot
import com.example.data.SortOption
import com.example.data.SortOrder
import com.example.data.VideoFolder
import com.example.data.VideoItem
import com.example.data.sortFolders
import com.example.data.sortVideos
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LibraryUiState(
    val isLoading: Boolean = true,
    val accessState: MediaAccessState = MediaAccessState.UNKNOWN,
    val allVideos: List<VideoItem> = emptyList(),
    val folders: List<VideoFolder> = emptyList(),
    val filteredFolders: List<VideoFolder> = emptyList(),
    val filteredVideos: List<VideoItem> = emptyList(),
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val activeTab: LibraryTab = LibraryTab.FOLDERS,
    val positionsByUri: Map<String, Long> = emptyMap(),
    val watchedUris: Set<String> = emptySet(),
    val continueWatchingVideo: VideoItem? = null,
    val continueWatchingPositionMs: Long = 0L,
    val activePlaylist: List<VideoItem> = emptyList(),
    val activeVideoIndex: Int = 0,
    val playerSessionKey: Int = 0
)

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val videoRepo = MediaStoreVideoRepository(application)
    private val prefsRepo = PlaybackPreferencesRepository(application)

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private var latestPrefs = PlaybackPreferencesSnapshot()

    init {
        viewModelScope.launch {
            prefsRepo.preferencesFlow.collect { snapshot ->
                latestPrefs = snapshot
                _uiState.update { current ->
                    recomputeDerivedLists(
                        current.copy(
                            sortOption = snapshot.sortOption,
                            sortOrder = snapshot.sortOrder,
                            positionsByUri = snapshot.positionsByUri,
                            watchedUris = snapshot.watchedUris
                        )
                    )
                }
            }
        }
        refreshPermissionAndScan()
    }

    fun refreshPermissionAndScan() {
        val access = videoRepo.checkMediaAccessState()
        _uiState.update { it.copy(accessState = access) }

        if (access == MediaAccessState.GRANTED_ALL || access == MediaAccessState.GRANTED_PARTIAL) {
            scanLibrary()
        } else {
            _uiState.update {
                recomputeDerivedLists(
                    it.copy(
                        isLoading = false,
                        allVideos = emptyList(),
                        folders = emptyList()
                    )
                )
            }
        }
    }

    fun scanLibrary() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val access = videoRepo.checkMediaAccessState()
            val scanned = if (access == MediaAccessState.GRANTED_ALL || access == MediaAccessState.GRANTED_PARTIAL) {
                videoRepo.scanAllVideos()
            } else {
                emptyList()
            }
            val grouped = videoRepo.groupVideosByFolder(scanned)
            _uiState.update { current ->
                recomputeDerivedLists(
                    current.copy(
                        isLoading = false,
                        accessState = access,
                        allVideos = scanned,
                        folders = grouped
                    )
                )
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { current ->
            recomputeDerivedLists(current.copy(searchQuery = query))
        }
    }

    fun onSelectTab(tab: LibraryTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun onSelectSort(option: SortOption, order: SortOrder) {
        viewModelScope.launch {
            prefsRepo.saveSortPreference(option, order)
        }
        _uiState.update { current ->
            recomputeDerivedLists(current.copy(sortOption = option, sortOrder = order))
        }
    }

    fun getFolderById(bucketId: String): VideoFolder? {
        val state = _uiState.value
        val folder = state.folders.find { it.bucketId == bucketId } ?: return null
        val q = state.searchQuery.trim().lowercase()
        val matching = if (q.isEmpty()) {
            folder.videos
        } else {
            folder.videos.filter {
                it.title.lowercase().contains(q) || it.displayName.lowercase().contains(q)
            }
        }
        return folder.copy(videos = sortVideos(matching, state.sortOption, state.sortOrder))
    }

    fun startPlayback(video: VideoItem, playlist: List<VideoItem>) {
        val index = playlist.indexOfFirst { it.uri == video.uri }.let { if (it >= 0) it else 0 }
        _uiState.update { state ->
            state.copy(
                activePlaylist = playlist.ifEmpty { listOf(video) },
                activeVideoIndex = index,
                playerSessionKey = state.playerSessionKey + 1
            )
        }
    }

    fun openExternalVideo(uri: Uri, onReady: () -> Unit) {
        viewModelScope.launch {
            val existing = _uiState.value.allVideos.find { it.uri == uri }
            val resolved = existing ?: videoRepo.resolveDocumentVideo(uri)
            val playlist = if (existing != null) {
                val folderVideos = _uiState.value.folders
                    .find { it.bucketId == existing.bucketId }?.videos ?: listOf(existing)
                sortVideos(folderVideos, _uiState.value.sortOption, _uiState.value.sortOrder)
            } else {
                listOf(resolved)
            }
            startPlayback(resolved, playlist)
            onReady()
        }
    }

    fun getResumePositionMs(uri: Uri): Long {
        val key = PlaybackPreferencesRepository.uriKey(uri.toString())
        return _uiState.value.positionsByUri[key] ?: 0L
    }

    fun savePlaybackProgress(uri: Uri, positionMs: Long, durationMs: Long) {
        viewModelScope.launch {
            prefsRepo.savePlaybackProgress(uri.toString(), positionMs, durationMs)
        }
    }

    private fun recomputeDerivedLists(state: LibraryUiState): LibraryUiState {
        val q = state.searchQuery.trim().lowercase()

        val sortedAll = sortVideos(state.allVideos, state.sortOption, state.sortOrder)
        val filteredAll = if (q.isEmpty()) {
            sortedAll
        } else {
            sortedAll.filter {
                it.title.lowercase().contains(q) ||
                    it.displayName.lowercase().contains(q) ||
                    it.folderName.lowercase().contains(q)
            }
        }

        val sortedFolders = sortFolders(
            state.folders.map { folder ->
                folder.copy(videos = sortVideos(folder.videos, state.sortOption, state.sortOrder))
            },
            state.sortOption,
            state.sortOrder
        )

        val filteredFolders = if (q.isEmpty()) {
            sortedFolders
        } else {
            sortedFolders.filter { folder ->
                folder.name.lowercase().contains(q) ||
                    folder.videos.any {
                        it.title.lowercase().contains(q) || it.displayName.lowercase().contains(q)
                    }
            }
        }

        val lastUri = latestPrefs.lastPlayedUri
        val continueVideo = if (lastUri != null) {
            state.allVideos.find { it.uri.toString() == lastUri }
        } else {
            null
        }
        val continuePos = if (continueVideo != null) {
            state.positionsByUri[PlaybackPreferencesRepository.uriKey(continueVideo.uri.toString())] ?: 0L
        } else {
            0L
        }

        return state.copy(
            filteredVideos = filteredAll,
            filteredFolders = filteredFolders,
            continueWatchingVideo = if (continuePos > 3_000L) continueVideo else null,
            continueWatchingPositionMs = continuePos
        )
    }
}
