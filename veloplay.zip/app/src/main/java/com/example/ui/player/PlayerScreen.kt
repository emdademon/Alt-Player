package com.example.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BrightnessHigh
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.compose.ContentFrame
import com.example.R
import com.example.data.VideoItem
import com.example.data.formatDuration
import com.example.player.AspectMode
import com.example.player.AudioTrackOption
import com.example.player.ExternalSubtitleTrack
import com.example.player.GestureFeedback
import com.example.player.SrtSubtitleParser
import com.example.player.SubtitleSelection
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletAccent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class DragMode {
    NONE,
    HORIZONTAL_SEEK,
    BRIGHTNESS,
    VOLUME
}

@Composable
fun PlayerScreen(
    playlist: List<VideoItem>,
    initialIndex: Int,
    getResumePositionMs: (Uri) -> Long,
    onSaveProgress: (Uri, Long, Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val coroutineScope = rememberCoroutineScope()

    var currentIndex by remember(playlist, initialIndex) {
        mutableIntStateOf(initialIndex.coerceIn(0, (playlist.size - 1).coerceAtLeast(0)))
    }
    val currentVideo = playlist.getOrNull(currentIndex) ?: run {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val exoPlayer = remember {
        val trackSelector = DefaultTrackSelector(context)
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build()
    }

    var isPlaying by remember { mutableStateOf(false) }
    var durationMs by remember { mutableLongStateOf(currentVideo.durationMs) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var lockedHintVisible by remember { mutableStateOf(false) }
    var aspectMode by remember { mutableStateOf(AspectMode.FIT) }
    var aspectToastLabel by remember { mutableStateOf<String?>(null) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    var audioTracks by remember { mutableStateOf<List<AudioTrackOption>>(emptyList()) }
    var embeddedSubtitles by remember { mutableStateOf<List<SubtitleSelection.Embedded>>(emptyList()) }
    val externalSubtitles = remember { mutableStateListOf<ExternalSubtitleTrack>() }
    var activeExternalSubId by remember { mutableStateOf<String?>(null) }
    var subtitlesDisabled by remember { mutableStateOf(false) }
    var embeddedCueText by remember { mutableStateOf("") }

    var showTrackSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }

    var gestureFeedback by remember { mutableStateOf<GestureFeedback?>(null) }
    var containerSize by remember { mutableStateOf(IntSize.Zero) }

    // Brightness & Volume state
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volumeFraction by remember {
        mutableFloatStateOf(
            audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume.toFloat()
        )
    }
    var brightnessFraction by remember {
        val initial = activity?.window?.attributes?.screenBrightness?.takeIf { it in 0f..1f } ?: 0.5f
        mutableFloatStateOf(initial)
    }

    // Track double-tap accumulation
    var lastDoubleTapTimeMs by remember { mutableLongStateOf(0L) }
    var accumulatedTapDeltaSec by remember { mutableIntStateOf(0) }
    var lastTapForward by remember { mutableStateOf(true) }

    // Keep screen on & hide system bars while in PlayerScreen
    DisposableEffect(activity, view) {
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())

        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window?.attributes = window?.attributes?.apply {
                screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Block accidental back press when controls are locked; save progress on back when unlocked
    BackHandler {
        if (isLocked) {
            lockedHintVisible = true
        } else {
            onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            onBack()
        }
    }

    // Load current video into ExoPlayer whenever currentVideo changes
    LaunchedEffect(currentVideo.uri) {
        val resumeMs = getResumePositionMs(currentVideo.uri)
        val startPos = if (resumeMs > 3_000L &&
            (currentVideo.durationMs <= 0L || resumeMs < currentVideo.durationMs - 5_000L)
        ) {
            resumeMs
        } else {
            0L
        }
        embeddedCueText = ""
        exoPlayer.setMediaItem(MediaItem.fromUri(currentVideo.uri), startPos)
        exoPlayer.prepare()
        exoPlayer.setPlaybackSpeed(playbackSpeed)
        exoPlayer.playWhenReady = true
    }

    // Player listener for play/pause state, tracks, and embedded cues
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (exoPlayer.duration != C.TIME_UNSET && exoPlayer.duration > 0L) {
                    durationMs = exoPlayer.duration
                }
                if (playbackState == Player.STATE_ENDED) {
                    onSaveProgress(currentVideo.uri, exoPlayer.duration, exoPlayer.duration)
                    if (currentIndex < playlist.lastIndex) {
                        currentIndex += 1
                    } else {
                        controlsVisible = true
                    }
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                audioTracks = extractAudioTracks(tracks)
                embeddedSubtitles = extractEmbeddedSubtitles(tracks)
            }

            override fun onCues(cueGroup: CueGroup) {
                embeddedCueText = cueGroup.cues
                    .mapNotNull { it.text?.toString()?.trim() }
                    .filter { it.isNotEmpty() }
                    .joinToString("\n")
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Pause on app background
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                exoPlayer.pause()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Smooth position polling + periodic progress save
    LaunchedEffect(exoPlayer, currentVideo.uri) {
        var tickCount = 0
        while (true) {
            if (!isScrubbing) {
                currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            }
            if (exoPlayer.duration != C.TIME_UNSET && exoPlayer.duration > 0L) {
                durationMs = exoPlayer.duration
            }
            tickCount++
            if (tickCount % 25 == 0 && exoPlayer.isPlaying) {
                onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
            }
            delay(200L)
        }
    }

    // Auto-hide controls after 3.5 seconds while playing
    LaunchedEffect(controlsVisible, isPlaying, isLocked, showTrackSheet, showSpeedSheet) {
        if (controlsVisible && isPlaying && !isLocked && !showTrackSheet && !showSpeedSheet) {
            delay(3500L)
            controlsVisible = false
        }
    }

    // Auto-hide locked hint
    LaunchedEffect(lockedHintVisible) {
        if (lockedHintVisible) {
            delay(2200L)
            lockedHintVisible = false
        }
    }

    // Auto-hide aspect mode toast
    LaunchedEffect(aspectToastLabel) {
        if (aspectToastLabel != null) {
            delay(1300L)
            aspectToastLabel = null
        }
    }

    // Auto-hide double-tap feedback
    LaunchedEffect(gestureFeedback) {
        if (gestureFeedback is GestureFeedback.DoubleTapSeek) {
            delay(900L)
            gestureFeedback = null
        }
    }

    // SRT document picker
    val srtPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val parsed = SrtSubtitleParser.loadFromUri(context, uri)
                if (parsed != null) {
                    val existingIdx = externalSubtitles.indexOfFirst { it.id == parsed.id }
                    if (existingIdx >= 0) {
                        externalSubtitles[existingIdx] = parsed
                    } else {
                        externalSubtitles.add(parsed)
                    }
                    activeExternalSubId = parsed.id
                    subtitlesDisabled = false
                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                }
            }
        }
    }

    // Compute active subtitle text (either external SRT or embedded Media3 cues)
    val activeExternalTrack = externalSubtitles.find { it.id == activeExternalSubId }
    val activeSubtitleText = when {
        subtitlesDisabled -> ""
        activeExternalTrack != null -> SrtSubtitleParser.findActiveCues(
            activeExternalTrack.cues,
            currentPositionMs
        )
        else -> embeddedCueText
    }

    val updatedIsLocked by rememberUpdatedState(isLocked)
    val updatedIsPlaying by rememberUpdatedState(isPlaying)
    val updatedDuration by rememberUpdatedState(durationMs)
    val viewConfig = LocalViewConfiguration.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .onSizeChanged { containerSize = it }
            // Tap & Double-tap gesture detector
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (updatedIsLocked) {
                            lockedHintVisible = !lockedHintVisible
                        } else {
                            controlsVisible = !controlsVisible
                        }
                    },
                    onDoubleTap = { offset ->
                        if (updatedIsLocked) {
                            lockedHintVisible = true
                            return@detectTapGestures
                        }
                        val width = containerSize.width.toFloat().coerceAtLeast(1f)
                        val isLeft = offset.x < width * 0.42f
                        val isRight = offset.x > width * 0.58f

                        if (!isLeft && !isRight) {
                            if (updatedIsPlaying) exoPlayer.pause() else exoPlayer.play()
                            return@detectTapGestures
                        }

                        val isForward = isRight
                        val now = System.currentTimeMillis()
                        if (now - lastDoubleTapTimeMs < 950L && lastTapForward == isForward) {
                            accumulatedTapDeltaSec += 10
                        } else {
                            accumulatedTapDeltaSec = 10
                        }
                        lastDoubleTapTimeMs = now
                        lastTapForward = isForward

                        val deltaMs = if (isForward) 10_000L else -10_000L
                        val maxDur = updatedDuration.takeIf { it > 0L } ?: Long.MAX_VALUE
                        val newPos = (exoPlayer.currentPosition + deltaMs).coerceIn(0L, maxDur)
                        exoPlayer.seekTo(newPos)
                        currentPositionMs = newPos
                        gestureFeedback = GestureFeedback.DoubleTapSeek(
                            isForward = isForward,
                            totalDeltaSeconds = accumulatedTapDeltaSec
                        )
                    }
                )
            }
            // MX Player-style vertical (brightness/volume) & horizontal (seek) swipe detector
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (updatedIsLocked) return@awaitEachGesture

                    val startX = down.position.x
                    val startY = down.position.y
                    var dragMode = DragMode.NONE
                    var cumulativeDx = 0f
                    var cumulativeDy = 0f

                    val initialPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                    var seekTargetMs = initialPosMs

                    val currentBrightness = activity?.window?.attributes?.screenBrightness
                        ?.takeIf { it in 0f..1f } ?: brightnessFraction
                    var activeBrightness = currentBrightness

                    val currentVolStep = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    var activeVol = currentVolStep.toFloat() / maxVolume.toFloat()

                    val slop = viewConfig.touchSlop

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) {
                            if (dragMode == DragMode.HORIZONTAL_SEEK) {
                                exoPlayer.seekTo(seekTargetMs)
                                currentPositionMs = seekTargetMs
                            }
                            if (dragMode != DragMode.NONE) {
                                gestureFeedback = null
                            }
                            break
                        }

                        val delta = change.positionChange()
                        cumulativeDx += delta.x
                        cumulativeDy += delta.y

                        if (dragMode == DragMode.NONE) {
                            val absX = abs(cumulativeDx)
                            val absY = abs(cumulativeDy)
                            if (absX > slop || absY > slop) {
                                dragMode = if (absX > absY) {
                                    DragMode.HORIZONTAL_SEEK
                                } else if (startX < containerSize.width / 2f) {
                                    DragMode.BRIGHTNESS
                                } else {
                                    DragMode.VOLUME
                                }
                            }
                        }

                        when (dragMode) {
                            DragMode.HORIZONTAL_SEEK -> {
                                change.consume()
                                val widthPx = containerSize.width.toFloat().coerceAtLeast(1f)
                                val totalSeekSpanMs = if (updatedDuration > 0L) {
                                    minOf(120_000L, maxOf(45_000L, updatedDuration / 2L))
                                } else {
                                    60_000L
                                }
                                val offsetFromStart = change.position.x - startX
                                val deltaMs = ((offsetFromStart / widthPx) * totalSeekSpanMs).toLong()
                                val maxDur = updatedDuration.takeIf { it > 0L } ?: Long.MAX_VALUE
                                seekTargetMs = (initialPosMs + deltaMs).coerceIn(0L, maxDur)
                                gestureFeedback = GestureFeedback.HorizontalSeek(
                                    targetMs = seekTargetMs,
                                    deltaMs = seekTargetMs - initialPosMs,
                                    durationMs = updatedDuration
                                )
                            }

                            DragMode.BRIGHTNESS -> {
                                change.consume()
                                val heightPx = (containerSize.height * 0.65f).coerceAtLeast(1f)
                                val deltaNorm = -delta.y / heightPx
                                activeBrightness = (activeBrightness + deltaNorm).coerceIn(0.01f, 1.0f)
                                brightnessFraction = activeBrightness
                                activity?.window?.let { w ->
                                    val attrs = w.attributes
                                    attrs.screenBrightness = activeBrightness
                                    w.attributes = attrs
                                }
                                gestureFeedback = GestureFeedback.Brightness(
                                    percent = (activeBrightness * 100f).roundToInt()
                                )
                            }

                            DragMode.VOLUME -> {
                                change.consume()
                                val heightPx = (containerSize.height * 0.65f).coerceAtLeast(1f)
                                val deltaNorm = -delta.y / heightPx
                                activeVol = (activeVol + deltaNorm).coerceIn(0f, 1f)
                                volumeFraction = activeVol
                                val targetStep = (activeVol * maxVolume).roundToInt().coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStep, 0)
                                gestureFeedback = GestureFeedback.Volume(
                                    percent = (activeVol * 100f).roundToInt(),
                                    isMuted = targetStep == 0
                                )
                            }

                            DragMode.NONE -> Unit
                        }
                    }
                }
            }
    ) {
        // Video Surface via Media3 ContentFrame
        ContentFrame(
            player = exoPlayer,
            modifier = Modifier.fillMaxSize(),
            contentScale = aspectMode.contentScale
        )

        // Subtitles Overlay
        if (activeSubtitleText.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        start = 24.dp,
                        end = 24.dp,
                        bottom = if (controlsVisible && !isLocked) 120.dp else 36.dp
                    )
                    .navigationBarsPadding()
            ) {
                Surface(
                    color = AmoledBlack.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = activeSubtitleText,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("subtitle_overlay_text")
                    )
                }
            }
        }

        // Gesture Feedback HUD (Brightness / Volume / Seek / Double-Tap)
        GestureFeedbackHud(
            feedback = gestureFeedback,
            aspectToastLabel = aspectToastLabel,
            modifier = Modifier.fillMaxSize()
        )

        // Controls Overlay (when unlocked)
        AnimatedVisibility(
            visible = controlsVisible && !isLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            PlayerControlsOverlay(
                title = currentVideo.title,
                resolutionLabel = currentVideo.resolutionLabel,
                extension = currentVideo.extension,
                isPlaying = isPlaying,
                currentPositionMs = if (isScrubbing) scrubPositionMs else currentPositionMs,
                durationMs = durationMs,
                playbackSpeed = playbackSpeed,
                aspectMode = aspectMode,
                hasPrevious = currentIndex > 0,
                hasNext = currentIndex < playlist.lastIndex,
                onBack = {
                    onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                    onBack()
                },
                onOpenTracks = { showTrackSheet = true },
                onOpenSpeed = { showSpeedSheet = true },
                onCycleAspect = {
                    aspectMode = aspectMode.next()
                    aspectToastLabel = aspectMode.label
                },
                onToggleRotation = {
                    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                    activity?.requestedOrientation = if (isLandscape) {
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                },
                onLock = {
                    isLocked = true
                    controlsVisible = false
                    lockedHintVisible = true
                },
                onPrevious = {
                    if (currentIndex > 0) {
                        onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                        currentIndex -= 1
                    }
                },
                onNext = {
                    if (currentIndex < playlist.lastIndex) {
                        onSaveProgress(currentVideo.uri, exoPlayer.currentPosition, exoPlayer.duration)
                        currentIndex += 1
                    }
                },
                onRewind10 = {
                    val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                    exoPlayer.seekTo(target)
                    currentPositionMs = target
                },
                onForward10 = {
                    val maxDur = durationMs.takeIf { it > 0L } ?: Long.MAX_VALUE
                    val target = (exoPlayer.currentPosition + 10_000L).coerceAtMost(maxDur)
                    exoPlayer.seekTo(target)
                    currentPositionMs = target
                },
                onTogglePlayPause = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                },
                onScrubChange = { pos ->
                    isScrubbing = true
                    scrubPositionMs = pos
                },
                onScrubFinished = {
                    exoPlayer.seekTo(scrubPositionMs)
                    currentPositionMs = scrubPositionMs
                    isScrubbing = false
                }
            )
        }

        // Locked State Unlock Pill
        AnimatedVisibility(
            visible = isLocked && lockedHintVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopStart)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(18.dp)
        ) {
            Surface(
                onClick = {
                    isLocked = false
                    lockedHintVisible = false
                    controlsVisible = true
                },
                color = AmoledBlack.copy(alpha = 0.82f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("unlock_screen_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = stringResource(R.string.unlock_screen),
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.screen_locked_hint),
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )
                }
            }
        }
    }

    if (showTrackSheet) {
        TrackSelectorSheet(
            audioTracks = audioTracks,
            embeddedSubtitles = embeddedSubtitles,
            externalSubtitles = externalSubtitles,
            selectedExternalId = activeExternalSubId,
            subtitlesDisabled = subtitlesDisabled,
            onSelectAudioTrack = { option ->
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(
                        TrackSelectionOverride(option.trackGroup.mediaTrackGroup, option.trackIndex)
                    )
                    .build()
                showTrackSheet = false
            },
            onSelectSubtitlesOff = {
                activeExternalSubId = null
                subtitlesDisabled = true
                embeddedCueText = ""
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTrackSheet = false
            },
            onSelectEmbeddedSubtitle = { sub ->
                activeExternalSubId = null
                subtitlesDisabled = false
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(
                        TrackSelectionOverride(sub.trackGroup.mediaTrackGroup, sub.trackIndex)
                    )
                    .build()
                showTrackSheet = false
            },
            onSelectExternalSubtitle = { ext ->
                activeExternalSubId = ext.id
                subtitlesDisabled = false
                embeddedCueText = ""
                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTrackSheet = false
            },
            onLoadExternalSrtClick = {
                srtPickerLauncher.launch(
                    arrayOf(
                        "application/x-subrip",
                        "text/plain",
                        "application/octet-stream",
                        "*/*"
                    )
                )
            },
            onDismiss = { showTrackSheet = false }
        )
    }

    if (showSpeedSheet) {
        SpeedSelectorSheet(
            currentSpeed = playbackSpeed,
            onSelectSpeed = { speed ->
                playbackSpeed = speed
                exoPlayer.setPlaybackSpeed(speed)
            },
            onDismiss = { showSpeedSheet = false }
        )
    }
}

@Composable
private fun PlayerControlsOverlay(
    title: String,
    resolutionLabel: String,
    extension: String,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    playbackSpeed: Float,
    aspectMode: AspectMode,
    hasPrevious: Boolean,
    hasNext: Boolean,
    onBack: () -> Unit,
    onOpenTracks: () -> Unit,
    onOpenSpeed: () -> Unit,
    onCycleAspect: () -> Unit,
    onToggleRotation: () -> Unit,
    onLock: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onRewind10: () -> Unit,
    onForward10: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onScrubChange: (Long) -> Unit,
    onScrubFinished: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Top scrim
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(AmoledBlack.copy(alpha = 0.85f), Color.Transparent)
                    )
                )
        )

        // Bottom scrim
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, AmoledBlack.copy(alpha = 0.9f))
                    )
                )
        )

        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("player_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.back),
                    tint = TextPrimary
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$resolutionLabel • $extension",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricCyan
                )
            }

            // Speed pill
            Surface(
                onClick = onOpenSpeed,
                color = Color.White.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .testTag("player_speed_button")
            ) {
                Text(
                    text = "${playbackSpeed}x",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                )
            }

            IconButton(
                onClick = onOpenTracks,
                modifier = Modifier.testTag("player_tracks_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Subtitles,
                    contentDescription = stringResource(R.string.audio_and_subtitles),
                    tint = TextPrimary
                )
            }

            IconButton(
                onClick = onCycleAspect,
                modifier = Modifier.testTag("player_aspect_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.AspectRatio,
                    contentDescription = "${stringResource(R.string.aspect_mode)}: ${aspectMode.label}",
                    tint = TextPrimary
                )
            }

            IconButton(
                onClick = onToggleRotation,
                modifier = Modifier.testTag("player_rotate_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.ScreenRotation,
                    contentDescription = stringResource(R.string.rotate_screen),
                    tint = TextPrimary
                )
            }
        }

        // Center Transport Controls
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            IconButton(
                onClick = onPrevious,
                enabled = hasPrevious,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("player_prev_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipPrevious,
                    contentDescription = stringResource(R.string.previous_video),
                    tint = if (hasPrevious) TextPrimary else TextSecondary.copy(alpha = 0.3f),
                    modifier = Modifier.size(30.dp)
                )
            }

            IconButton(
                onClick = onRewind10,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("player_rewind_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Replay10,
                    contentDescription = "Rewind 10 seconds",
                    tint = TextPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Surface(
                onClick = onTogglePlayPause,
                shape = CircleShape,
                color = ElectricCyan,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .size(68.dp)
                    .testTag("player_play_pause_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = stringResource(if (isPlaying) R.string.pause else R.string.play),
                        tint = AmoledBlack,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            IconButton(
                onClick = onForward10,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("player_forward_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Forward10,
                    contentDescription = "Forward 10 seconds",
                    tint = TextPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            IconButton(
                onClick = onNext,
                enabled = hasNext,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("player_next_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipNext,
                    contentDescription = stringResource(R.string.next_video),
                    tint = if (hasNext) TextPrimary else TextSecondary.copy(alpha = 0.3f),
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        // Bottom Bar: Seekbar + Lock + Aspect Pill
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = formatDuration(currentPositionMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )

                val safeDuration = durationMs.coerceAtLeast(1L)
                Slider(
                    value = currentPositionMs.coerceIn(0L, safeDuration).toFloat(),
                    onValueChange = { onScrubChange(it.toLong()) },
                    onValueChangeFinished = onScrubFinished,
                    valueRange = 0f..safeDuration.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricCyan,
                        activeTrackColor = ElectricCyan,
                        inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("player_seekbar")
                )

                Text(
                    text = formatDuration(durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onLock,
                    modifier = Modifier.testTag("player_lock_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LockOpen,
                        contentDescription = stringResource(R.string.lock_screen),
                        tint = TextPrimary
                    )
                }

                Surface(
                    onClick = onCycleAspect,
                    color = Color.White.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = aspectMode.label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GestureFeedbackHud(
    feedback: GestureFeedback?,
    aspectToastLabel: String?,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        when (feedback) {
            is GestureFeedback.Brightness -> {
                VerticalMeterHud(
                    icon = Icons.Rounded.BrightnessHigh,
                    label = stringResource(R.string.brightness),
                    percent = feedback.percent,
                    accentColor = Color(0xFFFFD54F),
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 32.dp)
                )
            }

            is GestureFeedback.Volume -> {
                VerticalMeterHud(
                    icon = if (feedback.isMuted) {
                        Icons.AutoMirrored.Rounded.VolumeOff
                    } else {
                        Icons.AutoMirrored.Rounded.VolumeUp
                    },
                    label = stringResource(R.string.volume),
                    percent = feedback.percent,
                    accentColor = ElectricCyan,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 32.dp)
                )
            }

            is GestureFeedback.HorizontalSeek -> {
                val deltaSec = feedback.deltaMs / 1000L
                val sign = if (deltaSec >= 0) "+" else "-"
                val absDeltaMs = abs(feedback.deltaMs)
                Surface(
                    color = AmoledBlack.copy(alpha = 0.82f),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = formatDuration(feedback.targetMs),
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "$sign${formatDuration(absDeltaMs)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = ElectricCyan
                        )
                    }
                }
            }

            is GestureFeedback.DoubleTapSeek -> {
                Surface(
                    color = AmoledBlack.copy(alpha = 0.78f),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .align(if (feedback.isForward) Alignment.CenterEnd else Alignment.CenterStart)
                        .padding(horizontal = 36.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!feedback.isForward) {
                            Icon(
                                imageVector = Icons.Rounded.FastRewind,
                                contentDescription = null,
                                tint = ElectricCyan
                            )
                        }
                        Text(
                            text = if (feedback.isForward) {
                                "+${feedback.totalDeltaSeconds}s"
                            } else {
                                "-${feedback.totalDeltaSeconds}s"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        if (feedback.isForward) {
                            Icon(
                                imageVector = Icons.Rounded.FastForward,
                                contentDescription = null,
                                tint = ElectricCyan
                            )
                        }
                    }
                }
            }

            null -> Unit
        }

        if (aspectToastLabel != null && feedback == null) {
            Surface(
                color = AmoledBlack.copy(alpha = 0.8f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = aspectToastLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = ElectricCyan,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun VerticalMeterHud(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    percent: Int,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = AmoledBlack.copy(alpha = 0.82f),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
            )

            Box(
                modifier = Modifier
                    .width(8.dp)
                    .height(110.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.White.copy(alpha = 0.18f)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight((percent / 100f).coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(accentColor, VioletAccent)
                            )
                        )
                )
            }

            Text(
                text = "$percent%",
                style = MaterialTheme.typography.labelMedium,
                color = TextPrimary
            )
        }
    }
}

private fun extractAudioTracks(tracks: Tracks): List<AudioTrackOption> {
    val result = mutableListOf<AudioTrackOption>()
    var counter = 1
    tracks.groups.forEachIndexed { groupIdx, group ->
        if (group.type == C.TRACK_TYPE_AUDIO) {
            for (trackIdx in 0 until group.length) {
                if (!group.isTrackSupported(trackIdx)) continue
                val format = group.getTrackFormat(trackIdx)
                val langCode = format.language.orEmpty()
                val langName = if (langCode.isNotBlank() && langCode != "und") {
                    Locale.forLanguageTag(langCode).displayLanguage.replaceFirstChar { it.uppercase() }
                } else {
                    "Audio Track $counter"
                }
                val title = format.label?.takeIf { it.isNotBlank() } ?: langName
                val channels = when (format.channelCount) {
                    1 -> "Mono"
                    2 -> "Stereo"
                    6 -> "5.1"
                    8 -> "7.1"
                    else -> if (format.channelCount > 0) "${format.channelCount}ch" else ""
                }
                val codec = format.sampleMimeType?.substringAfter('/')?.uppercase().orEmpty()
                val detail = listOf(channels, codec).filter { it.isNotBlank() }.joinToString(" • ")

                result.add(
                    AudioTrackOption(
                        id = "${groupIdx}_$trackIdx",
                        label = title,
                        detail = detail,
                        isSelected = group.isTrackSelected(trackIdx),
                        trackGroup = group,
                        trackIndex = trackIdx
                    )
                )
                counter++
            }
        }
    }
    return result
}

private fun extractEmbeddedSubtitles(tracks: Tracks): List<SubtitleSelection.Embedded> {
    val result = mutableListOf<SubtitleSelection.Embedded>()
    var counter = 1
    tracks.groups.forEachIndexed { groupIdx, group ->
        if (group.type == C.TRACK_TYPE_TEXT) {
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val langCode = format.language.orEmpty()
                val langName = if (langCode.isNotBlank() && langCode != "und") {
                    Locale.forLanguageTag(langCode).displayLanguage.replaceFirstChar { it.uppercase() }
                } else {
                    ""
                }
                val label = format.label?.takeIf { it.isNotBlank() }
                    ?: langName.ifBlank { "Subtitle Track $counter" }
                result.add(
                    SubtitleSelection.Embedded(
                        id = "${groupIdx}_$trackIdx",
                        label = label,
                        language = langName,
                        isSelected = group.isTrackSelected(trackIdx),
                        trackGroup = group,
                        trackIndex = trackIdx
                    )
                )
                counter++
            }
        }
    }
    return result
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
